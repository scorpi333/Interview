<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('interviews', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->timestamp('time');
            $table->integer('question_count');
            $table->integer('answer_count');
            $table->string('status');
            $table->string('type');
            $table->integer('percentage');
            $table->enum('difficulty_level', ["Easy","Medium","Hard"]);
            $table->boolean('ai_generated')->default(false);
            $table->int('duration');
            $table->integer('score');
            $table->foreignUuid('badge_id')->constrained();
            $table->foreignUuid('user_id')->constrained();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('interviews');
    }
};
