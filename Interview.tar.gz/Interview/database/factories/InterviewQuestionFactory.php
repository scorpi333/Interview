<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\InterviewQuestion;
use App\Models\Language;

class InterviewQuestionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = InterviewQuestion::class;

    /**
     * Define the model's default state.
     */
    public function definition(): array
    {
        return [
            'question' => fake()->text(),
            'answer' => fake()->text(),
            'level' => fake()->randomElement(["Easy","Medium","Hard"]),
            'attachment' => fake()->word(),
            'tags' => '{}',
            'source' => fake()->word(),
            'hints' => fake()->text(),
            'language_id' => Language::factory(),
        ];
    }
}
