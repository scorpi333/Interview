<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
use App\Models\Interview;
use App\Models\InterviewHistory;
use App\Models\InterviewQuestion;
use App\Models\User;

class InterviewHistoryFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = InterviewHistory::class;

    /**
     * Define the model's default state.
     */
    public function definition(): array
    {
        return [
            'question' => fake()->text(),
            'answer' => fake()->text(),
            'right' => fake()->boolean(),
            'time_taken' => fake()->time(),
            'feedback' => fake()->text(),
            'ai_feedback' => fake()->text(),
            'interview_id' => Interview::factory(),
            'interview_question_id' => InterviewQuestion::factory(),
            'user_id' => User::factory(),
        ];
    }
}
