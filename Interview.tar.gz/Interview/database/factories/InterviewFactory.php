<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
use App\Models\Badge;
use App\Models\Interview;
use App\Models\User;

class InterviewFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Interview::class;

    /**
     * Define the model's default state.
     */
    public function definition(): array
    {
        return [
            'id' => fake()->uuid(),
            'name' => fake()->name(),
            'time' => fake()->dateTime(),
            'question_count' => 50,
            'answer_count' => fake()->numberBetween(0, 50),
            'status' => fake()->word(),
            'percentage' => fake()->numberBetween(0, 100),
            'difficulty_level' => fake()->randomElement(["Easy","Medium","Hard"]),
            'ai_generated' => fake()->boolean(),
            'duration' => fake()->time(),
            'score' => fake()->numberBetween(0, 100),
            'badge_id' => Badge::factory(),
            'user_id' =>fake()->randomElement(['003a86d4-aa24-4951-b06b-d378650d5398','00482f0f-7cb3-41f5-8133-820b3414a53c']),
        ];
    }
}
