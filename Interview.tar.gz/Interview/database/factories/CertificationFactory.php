<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
use App\Models\Certification;
use App\Models\User;

class CertificationFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Certification::class;

    /**
     * Define the model's default state.
     */
    public function definition(): array
    {
        return [
            'id' => Str::uuid(),
            'user_id' => fake()->randomElement(['003a86d4-aa24-4951-b06b-d378650d5398','00482f0f-7cb3-41f5-8133-820b3414a53c']),
            'certificate_name' => fake()->word(),
            'issued_by' => fake()->word(),
            'issued_at' => fake()->date(),
            'valid_until' => fake()->date(),
            'attachment' => fake()->word(),
        ];
    }
}
