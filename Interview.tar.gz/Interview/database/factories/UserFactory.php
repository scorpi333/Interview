<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
use App\Models\User;

class UserFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = User::class;

    /**
     * Define the model's default state.
     */
    public function definition(): array
    {
        return [
            'id' => \Str::Uuid(),
            'name' => fake()->name(),
            'email' => fake()->safeEmail(),
            'phone' => fake()->phoneNumber(),
            'address' => fake()->word(),
            'linkedin1_url' => fake()->word(),
            'password' => fake()->password(),
            'resume' => fake()->word(),
            'profile' => fake()->text(),
            'status' => fake()->randomElement(["Active","Inactive"]),
            'type' => fake()->randomElement(["admin","regular"]),
            'profile_picture' => fake()->word(),
            'experience_level' => fake()->randomElement(["Beginner","Intermediate","Expert"]),
            'education' => '{}',
            'role' => fake()->randomElement(["Admin","Candidate","Interviewer"]),
            'bio' => fake()->text(),
        ];
    }
}
