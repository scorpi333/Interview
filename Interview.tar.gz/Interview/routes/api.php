<?php

use Illuminate\Support\Facades\Route;

Route::apiResource('/interview_questions', App\Http\Controllers\API\InterviewQuestionController::class);

Route::apiResource('/languages', App\Http\Controllers\API\LanguageController::class);
