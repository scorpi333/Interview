<?php

use Inertia\Inertia;
use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Application;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/dashboard', [DashboardController::class,'dashboard'])->middleware(['auth', 'verified'])->name('dashboard');


Route::middleware('auth')->group(function () {

    Route::get('/user-wizard/step-1', function () {
        return Inertia::render('Auth/Wizards/Step1');
    })->name('wizards-Step-1');

    Route::post('/user-wizard/step-1-save', [ App\Http\Controllers\UserController::class ,'storeWizard' ] )->name('wizards-Step-1-post');


    Route::get('/user-wizard/step-2', function () {
        return Inertia::render('Auth/Wizards/Step2');
    })->name('wizards-Step-2');

    Route::post('/user-wizard/step-2-save', [ App\Http\Controllers\UserController::class ,'storeWizard2' ] )->name('wizards-Step-2-post');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    
    Route::resource('languages', App\Http\Controllers\LanguageController::class);

    Route::resource('badges', App\Http\Controllers\BadgeController::class);
    Route::resource('/interviews', App\Http\Controllers\InterviewController::class);
    Route::resource('certifications', App\Http\Controllers\CertificationController::class);
    Route::post('/interview_questions/{languageId}', [App\Http\Controllers\InterviewQuestionController::class, 'index'])->name('interview_questions.index');
    
    // Route::post('/interview_questions/generate-question', [App\Http\Controllers\InterviewQuestionController::class, 'generateAIQuestion'])->name('interview_questions.generate-question');

    Route::post('/interview-questions/generate-question', [App\Http\Controllers\InterviewQuestionController::class, 'generateQuestion'])
    ->name('interview_questions.generate-question');
    
    Route::post('/interview-questions/store-multiple-data', [App\Http\Controllers\InterviewQuestionController::class, 'storeMultipleData'])->name('interview_questions.store-multiple-data');
    Route::resource('/interview_questions', App\Http\Controllers\InterviewQuestionController::class)->except('index');

    Route::resource('users', App\Http\Controllers\UserController::class);

    Route::get('/mock-test/start', [App\Http\Controllers\MockTestController::class, 'startMock'])->name('mock-test.start');
    Route::get('/interview/start', [App\Http\Controllers\MockTestController::class, 'startInterview'])->name('interview.start');

    Route::post('/interview/submit', [App\Http\Controllers\InterviewHistoryController::class, 'submitInterview'])->name('interview.submit');
    Route::post('/interview/submit-mock', [App\Http\Controllers\InterviewHistoryController::class, 'submitMock'])->name('interview.submit-mock');
    

    Route::resource('interview_histories', App\Http\Controllers\InterviewHistoryController::class);
});

require __DIR__.'/auth.php';




