<?php
namespace App\Services;

use App\Repositories\CertificationRepository;
use Exception;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class CertificationService
{
	/**
     * @var CertificationRepository $certificationRepository
     */
    protected $certificationRepository;

    /**
     * DummyClass constructor.
     *
     * @param CertificationRepository $certificationRepository
     */
    public function __construct(CertificationRepository $certificationRepository)
    {
        $this->certificationRepository = $certificationRepository;
    }

    /**
     * Get all certificationRepository.
     *
     * @return String
     */
    public function getAll()
    {
        return $this->certificationRepository->all();
    }

    /**
     * Get certificationRepository by id.
     *
     * @param $id
     * @return String
     */
    public function getById(int $id)
    {
        return $this->certificationRepository->getById($id);
    }

    /**
     * Validate certificationRepository data.
     * Store to DB if there are no errors.
     *
     * @param array $data
     * @return String
     */
    public function save(array $data)
    {
        return $this->certificationRepository->save($data);
    }

    /**
     * Update certificationRepository data
     * Store to DB if there are no errors.
     *
     * @param array $data
     * @return String
     */
    public function update(array $data, int $id)
    {
        DB::beginTransaction();
        try {
            $certificationRepository = $this->certificationRepository->update($data, $id);
            DB::commit();
            return $certificationRepository;
        } catch (Exception $e) {
            DB::rollBack();
            report($e);
            throw new InvalidArgumentException('Unable to update post data');
        }
    }

    /**
     * Delete certificationRepository by id.
     *
     * @param $id
     * @return String
     */
    public function deleteById(string $id)
    {
        DB::beginTransaction();
        try {
            $certificationRepository = $this->certificationRepository->delete($id);
            DB::commit();
            return $certificationRepository;
        } catch (Exception $e) {
            DB::rollBack();
            report($e);
            throw new InvalidArgumentException('Unable to delete post data');
        }
    }

}
