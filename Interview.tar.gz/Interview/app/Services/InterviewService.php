<?php
namespace App\Services;

use App\Models\Interview;
use App\Repositories\InterviewRepository;
use Exception;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class InterviewService
{
	/**
     * @var InterviewRepository $interviewRepository
     */
    protected $interviewRepository;

    /**
     * DummyClass constructor.
     *
     * @param InterviewRepository $interviewRepository
     */
    public function __construct(InterviewRepository $interviewRepository)
    {
        $this->interviewRepository = $interviewRepository;
    }

    /**
     * Get all interviewRepository.
     *
     * @return String
     */
    public function getAll()
    {
        return $this->interviewRepository->all();
    }

    /**
     * Get interviewRepository by id.
     *
     * @param $id
     * @return String
     */
    public function getById(string $id)
    {
        return $this->interviewRepository->getById($id);
    }

    /**
     * Validate interviewRepository data.
     * Store to DB if there are no errors.
     *
     * @param array $data
     * @return String
     */
    public function save(array $data)
    {
        return $this->interviewRepository->save($data);
    }

    /**
     * Update interviewRepository data
     * Store to DB if there are no errors.
     *
     * @param array $data
     * @return String
     */
    public function update(array $data, int $id)
    {
        DB::beginTransaction();
        try {
            $interviewRepository = $this->interviewRepository->update($data, $id);
            DB::commit();
            return $interviewRepository;
        } catch (Exception $e) {
            DB::rollBack();
            report($e);
            throw new InvalidArgumentException('Unable to update post data');
        }
    }

    /**
     * Delete interviewRepository by id.
     *
     * @param $id
     * @return String
     */
    public function deleteById(int $id)
    {
        DB::beginTransaction();
        try {
            $interviewRepository = $this->interviewRepository->delete($id);
            DB::commit();
            return $interviewRepository;
        } catch (Exception $e) {
            DB::rollBack();
            report($e);
            throw new InvalidArgumentException('Unable to delete post data');
        }
    }

}
