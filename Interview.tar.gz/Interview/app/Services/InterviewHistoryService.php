<?php
namespace App\Services;

use App\Models\InterviewHistory;
use App\Repositories\InterviewHistoryRepository;
use Exception;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class InterviewHistoryService
{
	/**
     * @var InterviewHistoryRepository $interviewHistoryRepository
     */
    protected $interviewHistoryRepository;

    /**
     * DummyClass constructor.
     *
     * @param InterviewHistoryRepository $interviewHistoryRepository
     */
    public function __construct(InterviewHistoryRepository $interviewHistoryRepository)
    {
        $this->interviewHistoryRepository = $interviewHistoryRepository;
    }

    /**
     * Get all interviewHistoryRepository.
     *
     * @return String
     */
    public function getAll()
    {
        return $this->interviewHistoryRepository->all();
    }

    /**
     * Get interviewHistoryRepository by id.
     *
     * @param $id
     * @return String
     */
    public function getById(int $id)
    {
        return $this->interviewHistoryRepository->getById($id);
    }

    /**
     * Validate interviewHistoryRepository data.
     * Store to DB if there are no errors.
     *
     * @param array $data
     * @return String
     */
    public function save(array $data)
    {
        return $this->interviewHistoryRepository->save($data);
    }

    /**
     * Update interviewHistoryRepository data
     * Store to DB if there are no errors.
     *
     * @param array $data
     * @return String
     */
    public function update(array $data, int $id)
    {
        DB::beginTransaction();
        try {
            $interviewHistoryRepository = $this->interviewHistoryRepository->update($data, $id);
            DB::commit();
            return $interviewHistoryRepository;
        } catch (Exception $e) {
            DB::rollBack();
            report($e);
            throw new InvalidArgumentException('Unable to update post data');
        }
    }

    /**
     * Delete interviewHistoryRepository by id.
     *
     * @param $id
     * @return String
     */
    public function deleteById(int $id)
    {
        DB::beginTransaction();
        try {
            $interviewHistoryRepository = $this->interviewHistoryRepository->delete($id);
            DB::commit();
            return $interviewHistoryRepository;
        } catch (Exception $e) {
            DB::rollBack();
            report($e);
            throw new InvalidArgumentException('Unable to delete post data');
        }
    }

}
