<?php
namespace App\Services;

use App\Repositories\BadgeRepository;
use Exception;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class BadgeService
{
	/**
     * @var BadgeRepository $badgeRepository
     */
    protected $badgeRepository;

    /**
     * DummyClass constructor.
     *
     * @param BadgeRepository $badgeRepository
     */
    public function __construct(BadgeRepository $badgeRepository)
    {
        $this->badgeRepository = $badgeRepository;
    }

    /**
     * Get all badgeRepository.
     *
     * @return String
     */
    public function getAll()
    {
        return $this->badgeRepository->all();
    }

    /**
     * Get badgeRepository by id.
     *
     * @param $id
     * @return String
     */
    public function getById(int $id)
    {
        return $this->badgeRepository->getById($id);
    }

    /**
     * Validate badgeRepository data.
     * Store to DB if there are no errors.
     *
     * @param array $data
     * @return String
     */
    public function save(array $data)
    {
        return $this->badgeRepository->save($data);
    }

    /**
     * Update badgeRepository data
     * Store to DB if there are no errors.
     *
     * @param array $data
     * @return String
     */
    public function update(array $data, string $id)
    {
        DB::beginTransaction();
        try {
            $badgeRepository = $this->badgeRepository->update($data, $id);
            DB::commit();
            return $badgeRepository;
        } catch (Exception $e) {
            DB::rollBack();
            report($e);
            throw new InvalidArgumentException('Unable to update post data');
        }
    }

    /**
     * Delete badgeRepository by id.
     *
     * @param $id
     * @return String
     */
    public function deleteById(int $id)
    {
        DB::beginTransaction();
        try {
            $badgeRepository = $this->badgeRepository->delete($id);
            DB::commit();
            return $badgeRepository;
        } catch (Exception $e) {
            DB::rollBack();
            report($e);
            throw new InvalidArgumentException('Unable to delete post data');
        }
    }

    /**
     * Get all badgeRepository by user id.
     *
     * @param $userId
     * @return String
     */
    public function getByUserId(string $userId)
    {
        return $this->badgeRepository->getByUserId($userId);
    }

}
