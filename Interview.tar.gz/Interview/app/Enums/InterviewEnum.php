<?php

namespace App\Enums;

enum InterviewEnum: string
{
    case Easy = 'Easy';
    case Medium = 'Medium';
    case Hard = 'Hard';

}
