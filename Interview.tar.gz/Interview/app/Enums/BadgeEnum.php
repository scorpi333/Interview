<?php

namespace App\Enums;

enum BadgeEnum: string
{
    case Active = 'Active';
    case Inactive = 'Inactive';

}
