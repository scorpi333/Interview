<?php
namespace App\Repositories;

use App\Models\Certification;

class CertificationRepository
{
	 /**
     * @var Certification
     */
    protected Certification $certification;

    /**
     * Certification constructor.
     *
     * @param Certification $certification
     */
    public function __construct(Certification $certification)
    {
        $this->certification = $certification;
    }

    /**
     * Get all certification.
     *
     * @return Certification $certification
     */
    public function all()
    {
        $user = auth()->user();
        if ($user->role == "Admin") {
            return $this->certification
            ->with('user')
            // ->leftjoin('users', 'certifications.user_id', '=', 'users.id')
            ->simplePaginate(10);
        }
        return $this->certification
        ->with('user')
        // ->leftjoin('users', 'certifications.user_id', '=', 'users.id')
        ->where('certifications.user_id',$user->id)
        ->simplePaginate(10);
    }

     /**
     * Get certification by id
     *
     * @param $id
     * @return mixed
     */
    public function getById(int $id)
    {
        return $this->certification->find($id);
    }

    /**
     * Save Certification
     *
     * @param $data
     * @return Certification
     */
     public function save(array $data)
    {
        return Certification::create($data);
    }

     /**
     * Update Certification
     *
     * @param $data
     * @return Certification
     */
    public function update(array $data, int $id)
    {
        $certification = $this->certification->find($id);
        $certification->update($data);
        return $certification;
    }

    /**
     * Delete Certification
     *
     * @param $data
     * @return Certification
     */
   	 public function delete(string $id)
    {
        $certification = $this->certification->find($id);
        $certification->delete();
        return $certification;
    }
}
