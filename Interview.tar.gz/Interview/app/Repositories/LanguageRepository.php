<?php
namespace App\Repositories;

use App\Models\Badge;
use App\Models\Language;

class LanguageRepository
{
	 /**
     * @var Language
     */
    protected Language $language;

    /**
     * Language constructor.
     *
     * @param Language $language
     */
    public function __construct(Language $language)
    {
        $this->language = $language;
    }

    /**
     * Get all language.
     *
     * @return Language $language
     */
    public function all()
    {
        return $this->language->withCount('interview_questions')->orderBy('id', 'desc')->simplePaginate(10);
        // return $this->language->get();
    }

     /**
     * Get language by id
     *
     * @param $id
     * @return mixed
     */
    public function getById(int $id)
    {
        return $this->language->find($id);
    }

    /**
     * Save Language
     *
     * @param $data
     * @return Language
     */
     public function save(array $data)
    {   
        $language = Language::create($data);
        $badge = [];
        $badge['id'] = $data['name'];
        $badge['name'] = $data['name'];
        $badge['language_id'] = $language->id;
        Badge::create($badge);
        return $language;
    }

     /**
     * Update Language
     *
     * @param $data
     * @return Language
     */
    public function update(array $data, string $id)
    {
        $language = $this->language->find($id);
        $language->update($data);

        $badge = Badge::where('language_id', $id)->first();
        if ($badge) {
            $badge->update($data);
        } else {
            $badge = [];
            $badge['id'] = $data['name'];
            $badge['name'] = $data['name'];
            $badge['language_id'] = $language->id;
            Badge::create($badge);
        } 
        return $language;
    }

    /**
     * Delete Language
     *
     * @param $data
     * @return Language
     */
   	 public function delete(string $id)
    {
        $language = $this->language->find($id);
        // delete Badge Relationship and Badge
        $badge = Badge::where('language_id', $id)->first();
        if ($badge) {
            $badge->delete();
        }
        $language->delete();
        return $language;
    }
}
