<?php
namespace App\Repositories;

use App\Models\Badge;
use App\Models\Interview;

class BadgeRepository
{
	 /**
     * @var Badge
     */
    protected Badge $badge;

    /**
     * Badge constructor.
     *
     * @param Badge $badge
     */
    public function __construct(Badge $badge)
    {
        $this->badge = $badge;
    }

    /**
     * Get all badge.
     *
     * @return Badge $badge
     */
    public function all()
    {   
        return $this->badge->with('language')->simplePaginate(10);
    }

     /**
     * Get badge by id
     *
     * @param $id
     * @return mixed
     */
    public function getById(int $id)
    {
        return $this->badge->find($id);
    }

    /**
     * Save Badge
     *
     * @param $data
     * @return Badge
     */
     public function save(array $data)
    {
        return Badge::create($data);
    }

     /**
     * Update Badge
     *
     * @param $data
     * @return Badge
     */
    public function update(array $data, string $id)
    {
        $badge = $this->badge->find($id);
        $badge->update($data);
        return $badge;
    }

    /**
     * Delete Badge
     *
     * @param $data
     * @return Badge
     */
   	 public function delete(int $id)
    {
        $badge = $this->badge->find($id);
        $badge->delete();
        return $badge;
    }
    /**
     * Get all badge by user id
     *
     * @param $id
     * @return mixed
     */
    public function getByUserId(string $id)
    {
       $badges = Interview::where([
           'user_id'=>$id
       ])
       ->with('badge')
        ->with('user')
       ->with('badge.language')
       ->withCount('badge')
       ->WherenotNull('badge_id')
         ->orderBy('id', 'desc')
       ->simplePaginate(10)->toArray();
       return $badges;

    
    }
}
