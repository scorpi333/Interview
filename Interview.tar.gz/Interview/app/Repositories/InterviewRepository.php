<?php
namespace App\Repositories;

use App\Models\Interview;

class InterviewRepository
{
	 /**
     * @var Interview
     */
    protected Interview $interview;

    /**
     * Interview constructor.
     *
     * @param Interview $interview
     */
    public function __construct(Interview $interview)
    {
        $this->interview = $interview;
    }

    /**
     * Get all interview.
     *
     * @return Interview $interview
     */
    public function all()
    {
        return $this->interview->with(
            'user:id,name,profile_picture',
            'badge:id,name'
        )->orderBy('created_at', 'desc')->simplePaginate(10);
    }

     /**
     * Get interview by id
     *
     * @param $id
     * @return mixed
     */
    public function getById(int $id)
    {
        return $this->interview->find($id);
    }

    /**
     * Save Interview
     *
     * @param $data
     * @return Interview
     */
     public function save(array $data)
    {
        return Interview::create($data);
    }

     /**
     * Update Interview
     *
     * @param $data
     * @return Interview
     */
    public function update(array $data, int $id)
    {
        $interview = $this->interview->find($id);
        $interview->update($data);
        return $interview;
    }

    /**
     * Delete Interview
     *
     * @param $data
     * @return Interview
     */
   	 public function delete(int $id)
    {
        $interview = $this->interview->find($id);
        $interview->delete();
        return $interview;
    }
}
