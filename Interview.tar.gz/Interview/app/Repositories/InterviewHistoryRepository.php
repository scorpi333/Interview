<?php
namespace App\Repositories;

use App\Models\InterviewHistory;

class InterviewHistoryRepository
{
	 /**
     * @var InterviewHistory
     */
    protected InterviewHistory $interviewHistory;

    /**
     * InterviewHistory constructor.
     *
     * @param InterviewHistory $interviewHistory
     */
    public function __construct(InterviewHistory $interviewHistory)
    {
        $this->interviewHistory = $interviewHistory;
    }

    /**
     * Get all interviewHistory.
     *
     * @return InterviewHistory $interviewHistory
     */
    public function all()
    {
        return $this->interviewHistory->get();
    }

     /**
     * Get interviewHistory by id
     *
     * @param $id
     * @return mixed
     */
    public function getById(int $id)
    {
        return $this->interviewHistory->find($id);
    }

    /**
     * Save InterviewHistory
     *
     * @param $data
     * @return InterviewHistory
     */
     public function save(array $data)
    {
        return InterviewHistory::create($data);
    }

     /**
     * Update InterviewHistory
     *
     * @param $data
     * @return InterviewHistory
     */
    public function update(array $data, int $id)
    {
        $interviewHistory = $this->interviewHistory->find($id);
        $interviewHistory->update($data);
        return $interviewHistory;
    }

    /**
     * Delete InterviewHistory
     *
     * @param $data
     * @return InterviewHistory
     */
   	 public function delete(int $id)
    {
        $interviewHistory = $this->interviewHistory->find($id);
        $interviewHistory->delete();
        return $interviewHistory;
    }
}
