<?php
namespace App\Repositories;

use App\Models\InterviewQuestion;

class InterviewQuestionRepository
{
	 /**
     * @var InterviewQuestion
     */
    protected InterviewQuestion $interviewQuestion;

    /**
     * InterviewQuestion constructor.
     *
     * @param InterviewQuestion $interviewQuestion
     */
    public function __construct(InterviewQuestion $interviewQuestion)
    {
        $this->interviewQuestion = $interviewQuestion;
    }

    /**
     * Get all interviewQuestion.
     *
     * @return InterviewQuestion $interviewQuestion
     */
    public function all($languageId)
    {
        return $this->interviewQuestion
        ->with('language')
        ->where('language_id', $languageId)
        ->orderBy('id', 'desc')->simplePaginate(10);
    }

     /**    
     * Get interviewQuestion by id
     *
     * @param $id
     * @return mixed
     */
    public function getById(string $id)
    {
        return $this->interviewQuestion->find($id);
    }

    /**
     * Save InterviewQuestion
     *
     * @param $data
     * @return InterviewQuestion
     */
     public function save(array $data)
    {
        return InterviewQuestion::create($data);
    }

     /**
     * Update InterviewQuestion
     *
     * @param $data
     * @return InterviewQuestion
     */
    public function update(array $data, int $id)
    {
        $interviewQuestion = $this->interviewQuestion->find($id);
        $interviewQuestion->update($data);
        return $interviewQuestion;
    }

    /**
     * Delete InterviewQuestion
     *
     * @param $data
     * @return InterviewQuestion
     */
   	 public function delete(int $id)
    {
        $interviewQuestion = $this->interviewQuestion->find($id);
        $interviewQuestion->delete();
        return $interviewQuestion;
    }
}
