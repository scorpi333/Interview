<?php

namespace App\Data;

use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Max;
use Spatie\LaravelData\Attributes\Validation\Date;
use Carbon\Carbon;


class UserData extends Data
{
   
    #[Max(36)]
    public string $id;
    #[Max(255)]
    public string $name;
    #[Max(255)]
    public string $email;
    #[Max(255)]
    public ?string $email_verified_at;
    #[Max(255)]
    public string $password;
    #[Max(255)]
    public ?string $phone;
    #[Max(255)]
    public ?string $address;
    #[Max(255)]
    public ?string $linkedin1_url;
    #[Max(255)]
    public ?string $resume;
    #[Max(255)]
    public ?string $profile;
    #[Max(255)]
    public string $status;
    #[Max(255)]
    public ?string $type;
    #[Max(255)]
    public ?string $profile_picture;
    #[Max(255)]
    public ?string $experience_level;
    #[Max(255)]
    public ?string $education;
    #[Max(255)]
    public ?string $role;
    #[Max(255)]
    public ?string $bio;
    #[Max(255)]
    public ?string $remember_token;
    #[Date]
    public Carbon $created_at;
    #[Date]
    public Carbon $updated_at;
    #[Date]
    public ?Carbon $deleted_at;
}
