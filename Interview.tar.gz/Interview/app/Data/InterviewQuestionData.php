<?php

namespace App\Data;

use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Enum;
use App\Enums\InterviewQuestionEnum;
use Spatie\LaravelData\Attributes\Validation\Max;
use Spatie\LaravelData\Attributes\Validation\Json;
use Spatie\LaravelData\Attributes\Validation\Date;
use Carbon\Carbon;


class InterviewQuestionData extends Data
{
    
    #[Max(36)]
    public string $id;
    
    public string $question;
    
    public string $answer;
    #[Enum(InterviewQuestionEnum::class)]

    public InterviewQuestionEnum $level;
    #[Max(255)]
    public ?string $attachment;
    // #[Json]
    // public string $tags;
    #[Max(255)]
    public string $source;
    
    public ?string $hints;
    #[Max(36)]
    public string $language_id;
    #[Date]
    public ?Carbon $deleted_at;

    // language relationship data
    public ?LanguageData $language;

    public ?UserData $user;

}
