<?php

namespace App\Data;

use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Max;
use Spatie\LaravelData\Attributes\Validation\Enum;
use App\Enums\BadgeEnum;
use Spatie\LaravelData\Attributes\Validation\Date;
use Carbon\Carbon;


class BadgeData extends Data
{
   
    #[Max(36)]
    public string $id;
    #[Max(255)]
    public string $name;
    #[Max(255)]
    public ?string $image;
    #[Max(255)]
    public string $category;

    // relatioship languages
    #[Max(36)]
    public string $language_id;
    
    public ?LanguageData $language;

    #[Enum(BadgeEnum::class)]
    public BadgeEnum $status;
    #[Date]
    public ?Carbon $deleted_at;

}
