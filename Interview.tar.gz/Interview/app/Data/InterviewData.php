<?php

namespace App\Data;

use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Max;
use Spatie\LaravelData\Attributes\Validation\Date;
use Carbon\Carbon;
use Spatie\LaravelData\Attributes\Validation\Enum;
use App\Enums\InterviewEnum;


class InterviewData extends Data
{
    #[Max(36)]
    public string $id;
    
    #[Max(255)]
    public string $name;
    #[Date]
    public  $time;
    
    public int $question_count;
    
    public int $answer_count;
    #[Max(255)]
    public string $status;
    #[Max(255)]
    public string $type;

    public int $percentage;
    #[Enum(InterviewEnum::class)]
    public InterviewEnum $difficulty_level;
    
    public int $ai_generated;
    
    public string $duration;
    
    public int $score;
    #[Max(36)]
    public string $badge_id;
    #[Max(36)]
    public string $user_id;
    #[Date]
    public ?Carbon $deleted_at;

    // add badge and User parameter
    public ?BadgeData $badge;
    public ?UserData $user;
  
    

}