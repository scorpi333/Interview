<?php

namespace App\Data;

use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Max;
use Spatie\LaravelData\Attributes\Validation\Date;


class CertificationData extends Data
{
    
    // #[Max(36)]
    // public string $id;
    #[Max(36)]
    public string $user_id;
    #[Max(255)]
    public string $certificate_name;
    #[Max(255)]
    public string $issued_by;
    #[Date]
    public  $issued_at;
    #[Date]
    public  $valid_until;
    #[Max(255)]
    public ?string $attachment;
    // User relationshp data
    public ?UserData $user;
    

}
