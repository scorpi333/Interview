<?php

namespace App\Data;

use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Max;
use Spatie\LaravelData\Attributes\Validation\Date;
use Carbon\Carbon;


class LanguageData extends Data
{
    #[Max(36)]
    public string $id;
    #[Max(255)]
    public string $name;
    #[Date]
    public ?Carbon $deleted_at;

}
