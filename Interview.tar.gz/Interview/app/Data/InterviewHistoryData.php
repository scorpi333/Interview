<?php

namespace App\Data;

use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Max;
use Spatie\LaravelData\Attributes\Validation\Date;
use Carbon\Carbon;


class InterviewHistoryData extends Data
{
    
    public string $question;
    
    public string $answer;
    
    public int $right;
    
    public string $time_taken;
    
    public ?string $feedback;
    
    public ?string $ai_feedback;
    #[Max(36)]
    public string $interview_id;
    #[Max(36)]
    public string $interview_question_id;
    #[Max(36)]
    public string $user_id;
    #[Date]
    public ?Carbon $deleted_at;

}
