<?php

namespace App\Http\Controllers;

use App\Models\User;
use Inertia\Inertia;
use App\Models\Badge;
use App\Models\Language;
use App\Models\Interview;
use App\Models\Certification;

class DashboardController extends Controller
{
    public function dashboard()  
    {

        $role =  auth()->user()->role;
        if ($role == 'Admin') {
            
            $total_users = User::count();
            $scheduled_interviews = Interview::where('status', 'scheduled')->count();
            $completed_interviews = Interview::where('status', 'completed')->count();
            $pending_feedback = Interview::where('status', 'pending_feedback')->count();
            $total_certifications = Certification::count();
            $total_languages = Language::count();
            $total_badges = Badge::count();
            $stats = [
                'total_users' => $total_users,
                'scheduled_interviews' => $scheduled_interviews,
                'completed_interviews' => $completed_interviews,
                'pending_feedback' => $pending_feedback, 
                'total_certifications' => $total_certifications,
                'total_languages' => $total_languages,
                'total_badges' => $total_badges,
            ];
            return Inertia::render('AdminDashboard', [
                'stats' => $stats,
            ]);
        }

        $user = auth()->user();
        $interviews = Interview::where('user_id', $user->id)->with('badge')->get();
        $mock_total = 0;
        $mock_passed = 0;
        $actual_total = 0;
        $actual_passed = 0;
        $last_interview_date = null;
        $badges = [];
        foreach ($interviews as $interview) {
            if ($interview->type == 'mock') {
                $mock_total++;
                if ($interview->status == 'completed') {
                    $mock_passed++;
                }
            } else {
                $actual_total++;
                if ($interview->status == 'completed') {
                    $actual_passed++;
                }
            }
            if ($last_interview_date === null || $interview->date > $last_interview_date) {
                $last_interview_date = $interview->date;
            }
            // Get badge details
            if ($interview->badge) {
                $badge = Badge::find($interview->badge_id);
                if ($badge) {
                    $badges[] = [
                        'id' => $badge->id,
                        'name' => $badge->name,
                        'date' => $interview->date,
                        'status' => $interview->status,
                    ];
                }
            }
        }
        $pass_rate = $mock_total > 0 ? ($mock_passed / $mock_total) * 100 : 0;
        $stats = [
            'mock_total' => $mock_total,
            'mock_passed' => $mock_passed,
            'actual_total' => $actual_total,
            'actual_passed' => $actual_passed,
            'pass_rate' => $pass_rate,
            'last_interview_date' => $last_interview_date,
        ];
        $certifications = Certification::where('user_id', $user->id)->get()->toArray();
        $certifications = array_map(function ($certification) {
            return [
                'id' => $certification['id'],
                'name' => $certification['name'],
                'date' => $certification['date'],
                'status' => $certification['status'],
            ];
        }, $certifications); 

        $languages = Language::get()->toArray();
        $languages = array_map(function ($language) {
            return [
                'id' => $language['id'],
                'name' => $language['name'],
            ];
        }, $languages);
        return Inertia::render('Dashboard',[
            'stats' => $stats,
            'certifications' => $certifications,
            'badges' => $badges,
            'languages' => $languages,
        ]);
    }
}
