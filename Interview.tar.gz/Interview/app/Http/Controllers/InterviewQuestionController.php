<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Inertia\Response;
use App\Data\InterviewQuestionData;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\InterviewQuestionService;

class InterviewQuestionController extends Controller
{
    /**
     * @var InterviewQuestionService
     */
    protected InterviewQuestionService $interviewQuestionService;

    /**
     * DummyModel Constructor
     *
     * @param InterviewQuestionService $interviewQuestionService
     *
     */
    public function __construct(InterviewQuestionService $interviewQuestionService)
    {
        $this->interviewQuestionService = $interviewQuestionService;
    }

    public function index(): Response
    {
        $interviewQuestions = InterviewQuestionData::collect($this->interviewQuestionService->getAll(""));
        $languages = \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray();
        return Inertia::render('InterviewQuestions/Index',[
            'interviewQuestions' => $interviewQuestions,
            'languages' => $languages
        ]);
    }

    public function create(): Response
    {
        return Inertia::render('InterviewQuestions/Create', [
            'languages' => \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray()
        ]);
    }

    public function store(InterviewQuestionData $data)
    {
        // Validate the request data
        $data->validate([
            'language_id' => 'required|string|max:255',
            'question' => 'required|string|max:255',
            'level' => 'required|string|max:255',
            'answer' => 'required|string|max:255',
            'tags' => 'string|max:255',
            'source' => 'string|max:255',
            'hints' => 'nullable|string|max:255',
            'question_type' => 'required|string|max:255',
        ]);
        $this->interviewQuestionService->save($data->all());
        return Redirect::route('interview_questions.index')->with('success', 'Created successfully');
    }

    public function show(string $id): Response
    {
        // $interviewQuestion = $this->interviewQuestionService->getById($id);
        $interviewQuestions = InterviewQuestionData::collect($this->interviewQuestionService->getAll($id));
        $languages = \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray();
        return Inertia::render('InterviewQuestions/Index',[
            'interviewQuestions' => $interviewQuestions,
            'languages' => $languages,
            'language_id' => $id
        ]);
    }

    public function edit(string $id): Response
    {
        $interviewQuestion = $this->interviewQuestionService->getById($id);
        return Inertia::render('InterviewQuestions/Edit', [
            'interviewQuestion' => $interviewQuestion,
            'languages' => \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray()
        ]);
    }

    public function update(InterviewQuestionData $data, string $id): \Illuminate\Http\RedirectResponse
    {
        $this->interviewQuestionService->update($data->all(), $id);
        return redirect()->route('interview_questions.index')->with('success', 'Updated successfully');
    }

    public function destroy(string $id): \Illuminate\Http\RedirectResponse
    {
        $this->interviewQuestionService->deleteById($id);
        return redirect()->route('interview_questions.index')->with('success', 'Deleted successfully');
    }

    public function generateAIQuestion(Request $request): \Illuminate\Http\RedirectResponse
    {
        $data = $request->validate([
            'language_id' => 'required|integer',
            'question' => 'required|string|max:255',
            'level' => 'required|string|max:255',
            'mcq' => 'required|numeric',
            'textarea' => 'required|numeric',
            'code' => 'required|numeric',
        ]);

        // Call chat gpt API to generate AI question
        $response = $this->interviewQuestionService->generateAIQuestion($data);
        if ($response['status'] !== 'success') {
            return Redirect::back()->with('error', 'Failed to generate AI question');
        }
        // Save the generated question to the database
        $this->interviewQuestionService->save([
            'language_id' => $data['language_id'],
            'question' => $response['question'],
            'level' => $data['level'],
            'mcq' => $data['mcq'],
            'textarea' => $data['textarea'],
            'code' => $data['code'],
        ]);
        
        // Redirect back with success message
        return Redirect::back()->with('success', 'AI question generated successfully');
        
    }
}
