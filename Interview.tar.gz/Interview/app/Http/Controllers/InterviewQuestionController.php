<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Inertia\Response;
use App\Data\InterviewQuestionData;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
// use Illuminate\Support\Facades\Request;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\InterviewQuestionService;

class InterviewQuestionController extends Controller
{
    /**
     * @var InterviewQuestionService
     */
    protected InterviewQuestionService $interviewQuestionService;

    /**
     * DummyModel Constructor
     *
     * @param InterviewQuestionService $interviewQuestionService
     *
     */
    public function __construct(InterviewQuestionService $interviewQuestionService)
    {
        $this->interviewQuestionService = $interviewQuestionService;
    }

    public function index(): Response
    {
        $interviewQuestions = InterviewQuestionData::collect($this->interviewQuestionService->getAll(""));
        $languages = \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray();
        return Inertia::render('InterviewQuestions/Index',[
            'interviewQuestions' => $interviewQuestions,
            'languages' => $languages
        ]);
    }

    public function create(): Response
    {
        return Inertia::render('InterviewQuestions/Create', [
            'languages' => \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray()
        ]);
    }

    public function store(InterviewQuestionData $data)
    {
        // Validate the request data
        $data->validate([
            'language_id' => 'required|string|max:255',
            'question' => 'required|string|max:255',
            'level' => 'required|string|max:255',
            'answer' => 'required|string|max:255',
            'tags' => 'string|max:255',
            'source' => 'string|max:255',
            'hints' => 'nullable|string|max:255',
            'question_type' => 'required|string|max:255',
        ]);
        $this->interviewQuestionService->save($data->all());
        return Redirect::route('interview_questions.index')->with('success', 'Created successfully');
    }

    public function show(string $id): Response
    {
        // $interviewQuestion = $this->interviewQuestionService->getById($id);
        $interviewQuestions = InterviewQuestionData::collect($this->interviewQuestionService->getAll($id));
        $languages = \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray();
        return Inertia::render('InterviewQuestions/Index',[
            'interviewQuestions' => $interviewQuestions,
            'languages' => $languages,
            'language_id' => $id
        ]);
    }

    public function edit(string $id): Response
    {
        $interviewQuestion = $this->interviewQuestionService->getById($id);
        return Inertia::render('InterviewQuestions/Edit', [
            'interviewQuestion' => $interviewQuestion,
            'languages' => \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray()
        ]);
    }

    public function update(InterviewQuestionData $data, string $id): \Illuminate\Http\RedirectResponse
    {
        $this->interviewQuestionService->update($data->all(), $id);
        return redirect()->route('interview_questions.index')->with('success', 'Updated successfully');
    }

    public function destroy(string $id): \Illuminate\Http\RedirectResponse
    {
        $this->interviewQuestionService->deleteById($id);
        return redirect()->route('interview_questions.index')->with('success', 'Deleted successfully');
    }

    public function generateQuestion(Request $request)
    {
        $request->validate([
            'language_id' => 'required',
            'language' => 'required|string|max:255',
            'level' => 'required|string|max:255',
            'mcq' => 'required|numeric',
            'textarea' => 'required|numeric',
            'code' => 'required|numeric',
        ]);
                    
        $content = 'Generate a JSON array of 8 structured technical interview questions related to '.$request->language.', with the following specifications:
                    Each question object should contain the keys: question, answer, question_type, option, level, tags, source, hints, language_id.
                    language_id must be set to "'.$request->language_id.'".
                    Create:
                    '.$request->mcq.' multiple choice questions (question_type: "mcq"
                    '.$request->textarea.' long-form questions (question_type: "text area")
                    '.$request->code.' coding questions (question_type: "code")
                    For mcq, include 4 options in the option array, with the correct answer clearly specified in the answer field.
                    level should be one of: "Easy", "Medium", "Hard" (distribute appropriately).
                    tags should be an array of relevant keywords like ["loops", "functions"].
                    source can be "AI Generated" or any reference name.
                    hints should provide a helpful tip or hint related to the question.
                    Return the final result as a Array with '.($request->mcq+$request->text_area+$request->code).' question objects.';

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer sk-pYOUR_API_KEY_HERE',
        ])->post('https://api.openai.com/v1/chat/completions', [
            'model' => 'gpt-4o-mini',
            'store' => true,
            'messages' => [
                ['role' => 'user', 'content' => $content]
            ],
        ]);

        // return  $response->json();  
        // question, answer, question_type, option, level, tags, source, hints, language_id  in python
        return [
            'data' => [
        [
            "question" => "What is the output of the following code: print(type([]))?",
            "answer" => "<class 'list'>",
            "question_type" => "mcq",
            "option" => ["<class 'tuple'>", "<class 'list'>", "<class 'dict'>", "<class 'set'>"],
            "level" => "Easy",
            "tags" => ["data types", "lists"],
            "source" => "AI Generated",
            "hints" => "The square brackets [] are used to define a list in Python.",
            "language_id" => "0196d2fd-b4b0-720a-a80e-7056d6206e2a"
        ],
        [
            "question" => "Which keyword is used to create a function in Python?",
            "answer" => "def",
            "question_type" => "mcq",
            "option" => ["func", "define", "def", "lambda"],
            "level" => "Easy",
            "tags" => ["functions", "syntax"],
            "source" => "AI Generated",
            "hints" => "The keyword is short for 'define'.",
            "language_id" => "0196d2fd-b4b0-720a-a80e-7056d6206e2a"
        ],
        [
            "question" => "What is the purpose of the 'self' keyword in Python class methods?",
            "answer" => "'self' refers to the instance of the class and is used to access variables and methods associated with the object.",
            "question_type" => "mcq",
            "option" => [
                "'self' refers to the parent class",
                "'self' is a global variable",
                "'self' refers to the class name",
                "'self' refers to the instance of the class"
            ],
            "level" => "Medium",
            "tags" => ["OOP", "classes", "methods"],
            "source" => "AI Generated",
            "hints" => "It's similar to 'this' in other object-oriented languages.",
            "language_id" => "0196d2fd-b4b0-720a-a80e-7056d6206e2a"
        ],
        [
            "question" => "Explain the difference between a list and a tuple in Python.",
            "answer" => "Lists are mutable, meaning their contents can be changed, while tuples are immutable. Lists use square brackets [], and tuples use parentheses ().",
            "question_type" => "textarea",
            "option" => [],
            "level" => "Easy",
            "tags" => ["data types", "lists", "tuples"],
            "source" => "AI Generated",
            "hints" => "Think about which one allows modifications after creation.",
            "language_id" => "0196d2fd-b4b0-720a-a80e-7056d6206e2a"
        ],
        [
            "question" => "Describe how Python handles memory management.",
            "answer" => "Python uses reference counting and garbage collection to manage memory. Objects are automatically deallocated when their reference count drops to zero.",
            "question_type" => "textarea",
            "option" => [],
            "level" => "Medium",
            "tags" => ["memory", "garbage collection", "reference counting"],
            "source" => "AI Generated",
            "hints" => "Consider how unused objects are cleaned up.",
            "language_id" => "0196d2fd-b4b0-720a-a80e-7056d6206e2a"
        ],
        [
            "question" => "What are Python decorators and how are they used?",
            "answer" => "Decorators are functions that modify the behavior of other functions or methods. They are commonly used for logging, enforcing access control, instrumentation, etc.",
            "question_type" => "textarea",
            "option" => [],
            "level" => "Hard",
            "tags" => ["functions", "decorators", "advanced"],
            "source" => "AI Generated",
            "hints" => "They are defined using the @ symbol above a function.",
            "language_id" => "0196d2fd-b4b0-720a-a80e-7056d6206e2a"
        ],
        [
            "question" => "Write a Python function that takes a list of numbers and returns a new list containing only the even numbers.",
            "answer" => "def filter_even(numbers):\n    return [num for num in numbers if num % 2 == 0]",
            "question_type" => "code",
            "option" => [],
            "level" => "Easy",
            "tags" => ["functions", "lists", "comprehension"],
            "source" => "AI Generated",
            "hints" => "Use list comprehension with a condition on modulus operator.",
            "language_id" => "0196d2fd-b4b0-720a-a80e-7056d6206e2a"
        ],
        [
            "question" => "Write a Python program to read a file and count the number of words in it.",
            "answer" => "def count_words(filename):\n    with open(filename, 'r') as file:\n        text = file.read()\n    words = text.split()\n    return len(words)",
            "question_type" => "code",
            "option" => [],
            "level" => "Medium",
            "tags" => ["file handling", "strings", "I/O"],
            "source" => "AI Generated",
            "hints" => "Use `open()`, `read()`, and `split()` functions.",
            "language_id" => "0196d2fd-b4b0-720a-a80e-7056d6206e2a"
        ]
    ]
        ];   
    }

    public function storeMultipleData(Request $request)
    {
        $data = $request->all();
        
        if (!is_array($request->questions) || count($request->questions) < 1) {
            return Redirect::back()->with('error', 'Need to generate AI questions.');
        }
        
    
        // store the Data in DB Interviwe Quesion
        foreach ($data['questions'] as $question) {

            // dump($question);
            $this->interviewQuestionService->save([
                'language_id' => $data['language_id'],
                'question' => $question['question'],
                'level' => $question['level'],
                'answer' => $question['answer'],
                'tags' => $question['tags'],
                'source' => $question['source'],
                'hints' => $question['hints'],
                'question_type' => $question['question_type'],
            ]);
        }
        // dd('dd');
        return Redirect::route('interview_questions.index', ['languageId' => $request->language_id])
        ->with('success', 'Created successfully');
        }
}
