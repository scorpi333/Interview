<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Inertia\Response;
use App\Data\InterviewQuestionData;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
// use Illuminate\Support\Facades\Request;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Services\InterviewQuestionService;

class InterviewQuestionController extends Controller
{
    /**
     * @var InterviewQuestionService
     */
    protected InterviewQuestionService $interviewQuestionService;

    /**
     * DummyModel Constructor
     *
     * @param InterviewQuestionService $interviewQuestionService
     *
     */
    public function __construct(InterviewQuestionService $interviewQuestionService)
    {
        $this->interviewQuestionService = $interviewQuestionService;
    }

    public function index(): Response
    {
        $interviewQuestions = InterviewQuestionData::collect($this->interviewQuestionService->getAll(""));
        $languages = \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray();
        return Inertia::render('InterviewQuestions/Index',[
            'interviewQuestions' => $interviewQuestions,
            'languages' => $languages
        ]);
    }

    public function create(): Response
    {
        return Inertia::render('InterviewQuestions/Create', [
            'languages' => \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray()
        ]);
    }

    public function store(InterviewQuestionData $data)
    {
        // Validate the request data
        $data->validate([
            'language_id' => 'required|string|max:255',
            'question' => 'required|string|max:255',
            'level' => 'required|string|max:255',
            'answer' => 'required|string|max:255',
            'tags' => 'string|max:255',
            'source' => 'string|max:255',
            'hints' => 'nullable|string|max:255',
            'question_type' => 'required|string|max:255',
        ]);
        $this->interviewQuestionService->save($data->all());
        return Redirect::route('interview_questions.index')->with('success', 'Created successfully');
    }

    public function show(string $id): Response
    {
        // $interviewQuestion = $this->interviewQuestionService->getById($id);
        $interviewQuestions = InterviewQuestionData::collect($this->interviewQuestionService->getAll($id));
        $languages = \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray();
        return Inertia::render('InterviewQuestions/Index',[
            'interviewQuestions' => $interviewQuestions,
            'languages' => $languages,
            'language_id' => $id
        ]);
    }

    public function edit(string $id): Response
    {
        $interviewQuestion = $this->interviewQuestionService->getById($id);
        return Inertia::render('InterviewQuestions/Edit', [
            'interviewQuestion' => $interviewQuestion,
            'languages' => \DB::table('languages')->whereNull('deleted_at')->select('id', 'name')->pluck('name','id')->toArray()
        ]);
    }

    public function update(InterviewQuestionData $data, string $id): \Illuminate\Http\RedirectResponse
    {
        $this->interviewQuestionService->update($data->all(), $id);
        return redirect()->route('interview_questions.index')->with('success', 'Updated successfully');
    }

    public function destroy(string $id): \Illuminate\Http\RedirectResponse
    {
        $this->interviewQuestionService->deleteById($id);
        return redirect()->route('interview_questions.index')->with('success', 'Deleted successfully');
    }

    public function generateQuestion(Request $request)
    {
        $request->validate([
            'language_id' => 'required',
            'language' => 'required|string|max:255',
            'level' => 'required|string|max:255',
            'mcq' => 'required|numeric',
            'textarea' => 'required|numeric',
            'code' => 'required|numeric',
        ]);

        $content = $prompt = "
        Generate a PHP json of " . ($request->mcq + $request->textarea + $request->code) . " structured technical interview questions related to " . $request->language . ", with the following specifications:
        
        - Return the result as a PHP json with the outer structure: ['data' => [ ... ]]
        - Each question object inside the json must include the following keys:
          - question: the interview question
          - answer: the correct answer or model answer
          - question_type: one of 'mcq', 'textarea', or 'code'
          - option: an array of 4 options (only for mcq, leave empty array for others)
          - level: one of 'Easy', 'Medium', or 'Hard' (distribute across questions)
          - tags: an array of relevant tags like ['loops', 'functions']
          - source: can be 'AI Generated'
          - hints: a helpful tip or hint related to the question
          - language_id: '" . $request->language_id . "'
        
        Question distribution:
        - " . $request->mcq . " multiple choice questions (question_type: 'mcq')
        - " . $request->textarea . " long-form questions (question_type: 'textarea')
        - " . $request->code . " coding questions (question_type: 'code')
        
        For MCQs:
        - Include 4 options in the 'option' array
        - Ensure the correct answer is present in the 'answer' field
        
        Respond with Direct json.
        
        Example output format:
        ```
        {
        'data': [
            {
            'question': 'What is the output of the following code: print(type([]))?',
            'answer': '<class 'list'>',
            'question_type': 'mcq',
            'option':  ['A', 'B', 'C', 'D'],
            'level': 'Easy',
            'tags': ['data types', 'lists'],
            'source': 'AI Generated',
            'hints': 'The square brackets [] are used to define a list in Python.',
            'language_id': '" . $request->language_id . "'
            },
            ...
            }
        }";
            

        // dd($content);        
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer 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', // Replace with your actual API key
        ])->timeout(90)
        ->post('https://api.openai.com/v1/chat/completions', [
            'model' => 'gpt-4o-mini',
            'store' => true,
            'messages' => [
                ['role' => 'user', 'content' => $content]
            ],
        ]);
        
        $data = $response->json();
        $content = $data['choices'][0]['message']['content'];

        // Remove triple backticks and optional "json" or "php" label
        $cleaned = trim($content);
        $cleaned = preg_replace('/^```(json|php)?/i', '', $cleaned); // Remove starting ```
        $cleaned = preg_replace('/```$/', '', $cleaned);             // Remove ending ```
    
        // Decode JSON string to PHP array
        $decoded = json_decode($cleaned, true);
    
        if (json_last_error() !== JSON_ERROR_NONE) {
            return response()->json([
                'error' => 'Failed to parse AI response as JSON.',
                'raw' => $cleaned,
                'json_error' => json_last_error_msg(),
            ], 500);
        }
    
        // Return as JSON to React frontend
        return response()->json($decoded);
    }

    public function storeMultipleData(Request $request)
    {
        $data = $request->all();
        
        if (!is_array($request->questions) || count($request->questions) < 1) {
            return Redirect::back()->with('error', 'Need to generate AI questions.');
        }
        
    
        // store the Data in DB Interviwe Quesion
        foreach ($data['questions'] as $question) {

            $this->interviewQuestionService->save([
                'question' => $question['question'],
                'answer' => $question['answer'],
                'question_type' => $question['question_type'],
                'option' =>  "['" . implode("', '", $question['option']) . "']",
                'level' => $question['level'],
                'tags' => $question['tags'],
                'source' => $question['source'],
                'hints' => $question['hints'],
                'language_id' => $data['language_id'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        // dd('dd');
        return Redirect::route('interview_questions.index', ['languageId' => $request->language_id])
        ->with('success', 'Created successfully');
        }
}
