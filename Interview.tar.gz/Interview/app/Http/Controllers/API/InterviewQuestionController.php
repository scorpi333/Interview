<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Data\InterviewQuestionData;
use App\Services\InterviewQuestionService;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class InterviewQuestionController extends Controller
{
    /**
     * @var InterviewQuestionService
     */
    protected InterviewQuestionService $interviewQuestionService;

    /**
     * DummyModel Constructor
     *
     * @param InterviewQuestionService $interviewQuestionService
     *
     */
    public function __construct(InterviewQuestionService $interviewQuestionService)
    {
        $this->interviewQuestionService = $interviewQuestionService;
    }

    public function index(): array|\Illuminate\Contracts\Pagination\CursorPaginator|\Illuminate\Contracts\Pagination\Paginator|\Illuminate\Pagination\AbstractCursorPaginator|\Illuminate\Pagination\AbstractPaginator|\Illuminate\Support\Collection|\Illuminate\Support\Enumerable|\Illuminate\Support\LazyCollection|\Spatie\LaravelData\CursorPaginatedDataCollection|\Spatie\LaravelData\DataCollection|\Spatie\LaravelData\PaginatedDataCollection
    {
        return InterviewQuestionData::collect($this->interviewQuestionService->getAll());
    }

    public function store(InterviewQuestionData $data): InterviewQuestionData|\Illuminate\Http\JsonResponse
    {
        try {
            return InterviewQuestionData::from($this->interviewQuestionService->save($data->all()));
        } catch (\Exception $exception) {
            report($exception);
            return response()->json(['error' => 'There is an error.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function show(int $id): InterviewQuestionData
    {
        return InterviewQuestionData::from($this->interviewQuestionService->getById($id));
    }

    public function update(InterviewQuestionData $data, int $id): InterviewQuestionData|\Illuminate\Http\JsonResponse
    {
        try {
            return InterviewQuestionData::from($this->interviewQuestionService->update($data->all(), $id));
        } catch (\Exception $exception) {
            report($exception);
            return response()->json(['error' => 'There is an error.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function destroy(int $id): \Illuminate\Http\JsonResponse
    {
        try {
            $this->interviewQuestionService->deleteById($id);
            return response()->json(['message' => 'Deleted successfully'], Response::HTTP_OK);
        } catch (\Exception $exception) {
            report($exception);
            return response()->json(['error' => 'There is an error.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
