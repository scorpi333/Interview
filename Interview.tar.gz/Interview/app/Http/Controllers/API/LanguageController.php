<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Data\LanguageData;
use App\Services\LanguageService;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class LanguageController extends Controller
{
    /**
     * @var LanguageService
     */
    protected LanguageService $languageService;

    /**
     * DummyModel Constructor
     *
     * @param LanguageService $languageService
     *
     */
    public function __construct(LanguageService $languageService)
    {
        $this->languageService = $languageService;
    }

    public function index(): array|\Illuminate\Contracts\Pagination\CursorPaginator|\Illuminate\Contracts\Pagination\Paginator|\Illuminate\Pagination\AbstractCursorPaginator|\Illuminate\Pagination\AbstractPaginator|\Illuminate\Support\Collection|\Illuminate\Support\Enumerable|\Illuminate\Support\LazyCollection|\Spatie\LaravelData\CursorPaginatedDataCollection|\Spatie\LaravelData\DataCollection|\Spatie\LaravelData\PaginatedDataCollection
    {
        return LanguageData::collect($this->languageService->getAll());
    }

    public function store(LanguageData $data): LanguageData|\Illuminate\Http\JsonResponse
    {
        try {
            return LanguageData::from($this->languageService->save($data->all()));
        } catch (\Exception $exception) {
            report($exception);
            return response()->json(['error' => 'There is an error.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function show(int $id): LanguageData
    {
        return LanguageData::from($this->languageService->getById($id));
    }

    public function update(LanguageData $data, int $id): LanguageData|\Illuminate\Http\JsonResponse
    {
        try {
            return LanguageData::from($this->languageService->update($data->all(), $id));
        } catch (\Exception $exception) {
            report($exception);
            return response()->json(['error' => 'There is an error.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function destroy(int $id): \Illuminate\Http\JsonResponse
    {
        try {
            $this->languageService->deleteById($id);
            return response()->json(['message' => 'Deleted successfully'], Response::HTTP_OK);
        } catch (\Exception $exception) {
            report($exception);
            return response()->json(['error' => 'There is an error.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
