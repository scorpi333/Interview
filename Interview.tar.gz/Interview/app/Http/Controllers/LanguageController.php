<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Language;
use App\Services\LanguageService;
use Inertia\Response;
use Inertia\Inertia;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class LanguageController extends Controller
{
    /**
     * @var LanguageService
     */
    protected LanguageService $languageService;

    /**
     * DummyModel Constructor
     *
     * @param LanguageService $languageService
     *
     */
    public function __construct(LanguageService $languageService)
    {
        $this->languageService = $languageService;
    }

    public function index(): Response
    
    {
        $languages = $this->languageService->getAll();
        return Inertia::render('Languages/Index', [
            'languages' => $languages,
        ]);
    }

    // public function create(): Response
    // {
    //     return view('languages.create');
    // }

    public function store(Request $request, Language $data)
    {
        $request->validate([
            'name' => 'required|string|max:255|unique:languages,name',
        ]);
        $this->languageService->save($request->all());
        return Redirect::route('languages.index')->with('success', 'Language created successfully');
    }

    // public function show(int $id): Response
    // {
    //     $language = $this->languageService->getById($id);
    //     return view('languages.show', compact('language'));
    // }

    public function update(Request $request , string $id)
    {
        $this->languageService->update($request->toArray(), $id);
        return Redirect::route('languages.index')->with('success', 'Updated successfully');
    }

    public function destroy(string $id)
    {
        $this->languageService->deleteById($id);
        return Redirect::route('languages.index')->with('success', 'Deleted successfully');
    }
}
