<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Fetch all users from the database
        $users = User::simplePaginate(10);

        // Return the users to the view
        return inertia('Users/Index', [
            'users' => $users,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // return inertia('Users/Create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate the request data
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        // Create a new user
        \App\Models\User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);

        // Redirect back with success message
        return redirect()->back()->with('success', 'User created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string|int $id)
    {
        // Find the user by ID
        $user = \App\Models\User::find($id);

        // Check if the user exists
        if (!$user) {
            return redirect()->back()->with('error', 'User not found');
        }

        // Return the user to the edit view
        return inertia('Users/Edit', [
            'user' => $user,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        // Find the user by ID
        $user = \App\Models\User::find($id);

        // Check if the user exists
        if (!$user) {
            return Redirect::back()->with('error', 'User not found');
        }

        // Update the user with the request data
        $user->update($request->all());

        // Redirect back with success message
        return Redirect::back()->with('success', 'User updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // Find the user by ID
        $user = \App\Models\User::find($id);

        // Check if the user exists
        if (!$user) {
            return redirect()->back()->with('error', 'User not found');
        }

        // Delete the user
        $user->delete();

        // Redirect back with success message
        return redirect()->back()->with('success', 'User deleted successfully');
    }

    // storeWizard
    public function storeWizard(Request $request)
    {
        $user = User::find(auth()->user()->id);
        // Store and validate resume and profile picture if the #user is blank
        if ($user->resume != null && $user->profile_picture != null) {
            return Redirect::route('wizards-Step-2')->with('error', 'Resume and profile picture already uploaded');
        }
        // Validate the request data
        $request->validate([
            'resume' => 'required|file|mimes:pdf,doc,docx|max:2048',
            'profile_picture' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);
        // Store wuht original filename
        $resumePath = $request->file('resume')->storeAs('resumes', $request->file('resume')->getClientOriginalName(), 'public');
        // generate the path and save it to the database
        $user = User::find(auth()->user()->id);
        $user->resume = $resumePath;
        // Store profile picture
        $profilePicturePath = $request->file('profile_picture')->storeAs('profile_pictures', $request->file('profile_picture')->getClientOriginalName(), 'public');
        // generate the path and save it to the database
        $user->profile_picture = $profilePicturePath;
        // Save the user
        $user->save();
        

        // Redirect back with success message
        return Redirect::route('wizards-Step-2')->with('success', 'Resume and profile picture uploaded successfully');
    }

    // storeWizard2
    public function storeWizard2(Request $request)
    {
        // Validate the request data
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'phone' => 'required|string|max:15',
            'linkedin1_url' => 'required|url',
            'skills' => 'required',
            'experience_level' => 'required|string',
            'address' => 'required|string|max:255',
        ]);

        // Store the skills, experience, and education in the database
        $user = User::find(auth()->user()->id);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->linkedin1_url = $request->linkedin1_url;
        $user->skills = $request->skills;
        $user->experience_level = $request->experience_level;
        $user->address = $request->address;
        // Save the user
        $user->save();

        // Redirect back with success message
        return Redirect::route('dashboard')->with('success', 'User information updated successfully');
    }
}
