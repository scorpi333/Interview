<?php

namespace App\Http\Controllers;

use App\Models\Interview;
use Illuminate\Http\Request;
use App\Models\InterviewHistory;
use App\Data\InterviewHistoryData;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Redirect;
use App\Services\InterviewHistoryService;

class InterviewHistoryController extends Controller
{
    /**
     * @var InterviewHistoryService
     */
    protected InterviewHistoryService $interviewHistoryService;

    /**
     * DummyModel Constructor
     *
     * @param InterviewHistoryService $interviewHistoryService
     *
     */
    public function __construct(InterviewHistoryService $interviewHistoryService)
    {
        $this->interviewHistoryService = $interviewHistoryService;
    }

    public function index(): \Illuminate\Contracts\View\View
    {
        $interview_histories = InterviewHistoryData::collect($this->interviewHistoryService->getAll());
        return view('interview_histories.index', compact('interview_histories'));
    }

    // public function create(): \Illuminate\Contracts\View\View
    // {
    //     return view('interview_histories.create');
    // }

    // public function store(InterviewHistoryData $data): \Illuminate\Http\RedirectResponse
    // {
    //     $this->interviewHistoryService->save($data->all());
    //     return redirect()->route('interview_histories.index')->with('success', 'Created successfully');
    // }

    // public function show(int $id): \Illuminate\Contracts\View\View
    // {
    //     $interviewHistory = $this->interviewHistoryService->getById($id);
    //     return view('interview_histories.show', compact('interviewHistory'));
    // }

    // public function edit(int $id): \Illuminate\Contracts\View\View
    // {
    //     $interviewHistory = $this->interviewHistoryService->getById($id);
    //     return view('interview_histories.edit', compact('interviewHistory'));
    // }

    // public function update(InterviewHistoryData $data, int $id): \Illuminate\Http\RedirectResponse
    // {
    //     $this->interviewHistoryService->update($data->all(), $id);
    //     return redirect()->route('interview_histories.index')->with('success', 'Updated successfully');
    // }

    // public function destroy(int $id): \Illuminate\Http\RedirectResponse
    // {
    //     $this->interviewHistoryService->deleteById($id);
    //     return redirect()->route('interview_histories.index')->with('success', 'Deleted successfully');
    // }

    public function submitInterview(Request $request) 
    {
        $request = $request->all();

        // Calcluate this data for history score , percentage, answer_count
        $score = 0;
        $answerCount = 0;
        $totalQuestions = count($request['history']);



        // Store in Interview History db
        foreach ($request['history'] as $key => $value) {
            $interviewHistory = InterviewHistory::create([
            'user_id' => auth()->user()->id,
            'interview_question_id' => $value['interview_question_id'],
            'interview_id' => $request['id'],
            'question' => $value['question'],
            'answer' => $value['answer'] ?? "",
            'right' => $value['right'], 
            'time_taken' => $value['time_taken'],
            'feedback' => $value['feedback'],
            'ai_feedback' => $value['ai_feedback'],
            ]);
            if (!empty($value['answer'])) {
                $answerCount++; // user attempted this question
                if ($value['right']) {
                    $score++; // user got it right
                }
            }
        }
        $percentage = $totalQuestions > 0 ? ($score / $totalQuestions) * 100 : 0;

        // Update Interview db based on the data



        $content =  'Generate the feedback for the user '. auth()->user()->name . ' based on the following interview history: ' . json_encode($request['history']) . ' and the score is ' . $score . ' out of ' . $totalQuestions . ' and the percentage is ' . $percentage . '%';
        $aiGenerateFeadback = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer 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', // Replace with your actual API key
        ])->timeout(90)
        ->post('https://api.openai.com/v1/chat/completions', [
            'model' => 'gpt-4o-mini',
            'store' => true,
            'messages' => [
                ['role' => 'user', 'content' => $content]
            ],
        ]);
        $aiGenerateFeadback = $aiGenerateFeadback->json();
        $aiGenerateFeadback = $aiGenerateFeadback['choices'][0]['message']['content'];
        Interview::where([
            'id' => $request['id'],
            'user_id' => auth()->user()->id,
        ])->update([
            'status' => 'completed',
            'score' => $score,
            'percentage' => $percentage,
            'answer_count' => $answerCount,
            'badge_id' =>  $percentage >= 80 ? \DB::table('badges')->where('language_id',$request['language'])->value('id') : null,
            'ai_generated' => $aiGenerateFeadback,
        ]);

        return Redirect::route('dashboard')->with('success', 'Interview submitted successfully');
        
        
    }

    public function submitMock(Request $request) 
    {
        $request = $request->all();

        // Calcluate this data for history score , percentage, answer_count
        $score = 0;
        $answerCount = 0;
        $totalQuestions = count($request['history']);



        // Store in Interview History db
        foreach ($request['history'] as $key => $value) {
            $interviewHistory = InterviewHistory::create([
            'user_id' => auth()->user()->id,
            'interview_question_id' => $value['interview_question_id'],
            'interview_id' => $request['id'],
            'question' => $value['question'],
            'answer' => $value['answer'],
            'right' => $value['right'], 
            'time_taken' => $value['time_taken'],
            'feedback' => $value['feedback'],
            'ai_feedback' => $value['ai_feedback'],
            ]);
            if (!empty($value['answer'])) {
                $answerCount++; // user attempted this question
                if ($value['right']) {
                    $score++; // user got it right
                }
            }
        }
        $percentage = $totalQuestions > 0 ? ($score / $totalQuestions) * 100 : 0;

        // Update Interview db based on the data
        
        Interview::where([
            'id' => $request['id'],
            'user_id' => auth()->user()->id,
        ])->update([
            'status' => 'completed',
            'score' => $score,
            'percentage' => $percentage,
            'answer_count' => $answerCount,
        ]);

        return Redirect::route('dashboard')->with('success', 'Mock Test submitted successfully');
        
    }
}
