<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use App\Data\InterviewData;
use App\Services\InterviewService;
use App\Http\Controllers\Controller;

class InterviewController extends Controller
{
    /**
     * @var InterviewService
     */
    protected InterviewService $interviewService;

    /**
     * DummyModel Constructor
     *
     * @param InterviewService $interviewService
     *
     */
    public function __construct(InterviewService $interviewService)
    {
        $this->interviewService = $interviewService;
    }

    public function index()
    {
        $interviews = InterviewData::collect($this->interviewService->getAll());
        return Inertia::render('Interviews/Index', [
            'interviews' => $interviews,
        ]);
    }

    // public function create()
    // {
    //     return view('interviews.create');
    // }

    public function store(InterviewData $data): \Illuminate\Http\RedirectResponse
    {
        $this->interviewService->save($data->all());
        return redirect()->route('interviews.index')->with('success', 'Created successfully');
    }

    // public function show(int $id)
    // {
    //     $interview = $this->interviewService->getById($id);
    //     return view('interviews.show', compact('interview'));
    // }

    // public function edit(int $id)
    // {
    //     $interview = $this->interviewService->getById($id);
    //     return view('interviews.edit', compact('interview'));
    // }

    // public function update(InterviewData $data, int $id): \Illuminate\Http\RedirectResponse
    // {
    //     $this->interviewService->update($data->all(), $id);
    //     return redirect()->route('interviews.index')->with('success', 'Updated successfully');
    // }

    // public function destroy(int $id): \Illuminate\Http\RedirectResponse
    // {
    //     $this->interviewService->deleteById($id);
    //     return redirect()->route('interviews.index')->with('success', 'Deleted successfully');
    // }
}
