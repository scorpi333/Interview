<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Inertia\Response;
use App\Models\Certification;
use App\Data\CertificationData;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Services\CertificationService;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;

class CertificationController extends Controller
{
    /**
     * @var CertificationService
     */
    protected CertificationService $certificationService;

    /**
     * DummyModel Constructor
     *
     * @param CertificationService $certificationService
     *
     */
    public function __construct(CertificationService $certificationService)
    {
        $this->certificationService = $certificationService;
    }

    public function index(): Response
    {
        $certifications = $this->certificationService->getAll();
        return Inertia::render('Certifications/Index',[
            'certifications' => $certifications
        ]);
    }

    public function create(): Response
    {
        $users = DB::table('users')->select('id','name')->where([
            'status' => 'Active',
            'role' => 'Candidate'
        ])->pluck('name','id')->toArray();

        $languages = DB::table('languages')->select('id','name')->pluck('name','id')->toArray();

        return Inertia::render('Certifications/Create',[
        'users' => $users,
        'languages' =>$languages,
        ]);
    }

    public function store(CertificationData $data)
    {
        $data->validate([
            'user_id' => 'required|exists:users,id',
            'certificate_name' => 'required|string|max:255',
            'issued_by' => 'required|string|max:255',
            // 'issued_at' => 'required|date',
            // 'valid_until' => 'required|date',
        ]);
        // generate the pdf and store in db and store paath in db
        $pdf = Pdf::loadHTML(view('certifications.certification', ['cred' => $data]));
        $pdf->setPaper('A4', 'landscape');
        $pdf->setOptions([
            'isHtml5ParserEnabled' => true,
            'isRemoteEnabled' => true,
            'defaultFont' => 'sans-serif',
            'dpi' => 96,
            'isPhpEnabled' => true,
        ]);
        $pdf->setOption('isFontSubsettingEnabled', true);

        $fileName = str_replace(' ', '', $data->user_id .now());
        $filePath = 'certifications/' . $fileName . '.pdf';
        Storage::disk('public')->put($filePath, $pdf->output());
        
        $data->attachment = $filePath;
        $certification = $this->certificationService->save($data->all());


        return Redirect::route('certifications.index')->with('success', 'Created successfully');
    }

    public function show(string $id)
    {
        $cert = Certification::findOrFail($id);

        $pdf = Pdf::loadHTML(view('certifications.certification', compact('cert')));
        $pdf->setPaper('A4', 'landscape');
        $pdf->setOptions([
            'isHtml5ParserEnabled' => true,
            'isRemoteEnabled' => true,
            'defaultFont' => 'sans-serif',
            'dpi' => 96,
            'isPhpEnabled' => true,
        ]);
        $pdf->setOption('isFontSubsettingEnabled', true);

        return $pdf->download('certificate.pdf');
    }

    public function edit(int $id): Response
    {
        $certification = $this->certificationService->getById($id);
        return view('certifications.edit', compact('certification'));
    }

    public function update(CertificationData $data, int $id)
    {
        $this->certificationService->update($data->all(), $id);
        return redirect()->route('certifications.index')->with('success', 'Updated successfully');
    }

    public function destroy(string $id)
    {
        $this->certificationService->deleteById($id);
        return redirect()->route('certifications.index')->with('success', 'Deleted successfully');
    }
}
