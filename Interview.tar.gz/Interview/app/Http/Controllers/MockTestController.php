<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use App\Models\Interview;
use Illuminate\Http\Request;
use App\Models\InterviewQuestion;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class MockTestController extends Controller
{
    public function startMock(Request $request) 
    {
        
        $languageId = $request->input('language_id');
        $level = $request->input('level');

        $languageName = DB::table('languages')->where('id', $languageId)->value('name');
        if (!$languageId) {
            return Redirect::back()->with('error', 'Language ID is required.');
        }
     
        $interviewQuestion = InterviewQuestion::where(
        [
            'language_id' => $languageId,
            'level' => $level
        ]
        )->simplePaginate(50)->toArray();

        if (count($interviewQuestion['data']) == 0) {
            return Redirect::back()->with('error','Mock Test can not be Start.');
        }

        $interview = Interview::where([
            'status'=>'scheduled',
            'user_id' => auth()->user()->id,
            ])->get()->toArray();
        $interview = $interview[0] ?? [];

        if(empty($interview))
        {
            $interview = Interview::create([
                'name' =>'Mock Test ' . $languageName . ' ' . now()->format('d-m-Y'),
                'time' => now(),
                'question_count' => count($interviewQuestion['data']),
                'answer_count' => 0,
                'status' => 'scheduled',
                'type' => 'mock',
                'percentage' => 0,
                'difficulty_level' => $level,
                'ai_generated' => false,
                'duration' => 60,
                'score' => 0,
                'badge_id' => null,
                'user_id' => auth()->user()->id,
            ]);
            $interview = $interview->toArray();
        }

        return Inertia::render('MockTests/Start',[
            'questions' => $interviewQuestion,
            'interview' => $interview,
            'language' => $languageId,
        ]);
    }

    public function startInterview(Request $request) 
    {
        $languageId = $request->input('language_id');
        $level = $request->input('level');

        $languageName = DB::table('languages')->where('id', $languageId)->value('name');
        if (!$languageId) {
            return Redirect::back()->with('error', 'Language ID is required.');
        }
     
        $interviewQuestion = InterviewQuestion::where(
            [
                'language_id' => $languageId,
                'level' => $level
            ]
        )->simplePaginate(50)->toArray();

        if (count($interviewQuestion['data']) == 0) {
            return Redirect::back()->with('error','Interview can not be Start.');
        }

        $interview = Interview::where([
            'status'=>'scheduled',
            'user_id' => auth()->user()->id,
            ])->get()->toArray();
        $interview = $interview[0] ?? [];

        if(empty($interview))
        {
            $interview = Interview::create([
                'name' =>'Interview ' . $languageName . ' ' . now()->format('d-m-Y'),
                'time' => now(),
                'question_count' => count($interviewQuestion['data']),
                'answer_count' => 0,
                'status' => 'scheduled',
                'type' => 'actual',
                'percentage' => 0,
                'difficulty_level' => $level,
                'ai_generated' => false,
                'duration' => 60,
                'score' => 0,
                'badge_id' => null,
                'user_id' => auth()->user()->id,
            ]);
            $interview = $interview->toArray();
        }

        return Inertia::render('MockTests/Actual',[
            'questions' => $interviewQuestion,
            'interview' => $interview,
            'language' => $languageId,
        ]);
    }
}
