<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Http\Request;
use App\Services\BadgeService;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;


class BadgeController extends Controller
{
    /**
     * @var BadgeService
     */
    protected BadgeService $badgeService;

    /**
     * DummyModel Constructor
     *
     * @param BadgeService $badgeService
     *
     */
    public function __construct(BadgeService $badgeService)
    {
        $this->badgeService = $badgeService;
    }

    public function index(): Response
    {

        $languages = DB::table('languages')->select('name','id')->pluck('name','id');

        $user = auth()->user();
        $role = $user->role;
        if ($role != 'Admin') {
            $badges = $this->badgeService->getByUserId($user->id);
            return Inertia::render('Badges/Index', [
                'badges' => $badges,
                'languages' => $languages,
            ]);  
        }
        $badges = $this->badgeService->getAll();
        return Inertia::render('Badges/Index', [
            'badges' => $badges,
            'languages' => $languages,
        ]);
    }

    // public function create(): Response
    // {
    //     return view('badges.create');
    // }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'id' => 'required|string|max:255',
            'status' => 'required|string|max:255',
        ]);
        // $data = $request->all();
        // $pdf = Pdf::loadHTML(view('batches.badge', ['name' => $data['name']]));
        // $pdf->setPaper('A4', 'landscape');
        // $pdf->setOptions([
        //     'isHtml5ParserEnabled' => true,
        //     'isRemoteEnabled' => true,
        //     'defaultFont' => 'sans-serif',
        //     'dpi' => 96,
        //     'isPhpEnabled' => true,
        // ]);
        // $pdf->setOption('isFontSubsettingEnabled', true);

        // $fileName = str_replace(' ', '', $data['id'] .now());
        // $filePath = 'batches/' . $fileName . '.pdf';
        // Storage::disk('public')->put($filePath, $pdf->output());
        
        // $data['image'] = $filePath;
        
        $this->badgeService->save($data);
        return Redirect::route('badges.index')->with('success', 'Created successfully');
    }

    // public function show(int $id): Response
    // {
    //     $badge = $this->badgeService->getById($id);
    //     return view('badges.show', compact('badge'));
    // }

    // public function edit(int $id): Response
    // {
    //     $badge = $this->badgeService->getById($id);
    //     return view('badges.edit', compact('badge'));
    // }

    public function update(Request $request, string $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'id' => 'required|string|max:255',
        ]);
        $request = $request->all();
        $base64Image = $request['image']; // 'data:image/png;base64,...'

        // Validate format
        if (preg_match('/^data:image\/(\w+);base64,/', $base64Image, $type)) {
            $data = substr($base64Image, strpos($base64Image, ',') + 1);
            $type = strtolower($type[1]); // jpg, png, gif

            if (!in_array($type, ['jpg', 'jpeg', 'png', 'gif'])) {
                return response()->json(['error' => 'Invalid image type'], 400);
            }

            $data = base64_decode($data);

            if ($data === false) {
                return response()->json(['error' => 'Base64 decode failed'], 400);
            }
        } else {
            return response()->json(['error' => 'Invalid image format'], 400);
        }

        // Generate a filename
        $fileName = uniqid() . '.' . $type;

        // Store image in public/images (you can change this path)
        Storage::disk('public')->put('images/' . $fileName, $data);
        // Save the path to the database
        $request['image'] = '/storage/images/' . $fileName;
        $this->badgeService->update($request, $id);
        return Redirect::route('badges.index')->with('success', 'Updated successfully');
    }

    // public function destroy(int $id): \Illuminate\Http\RedirectResponse
    // {
    //     $this->badgeService->deleteById($id);
    //     return redirect()->route('badges.index')->with('success', 'Deleted successfully');
    // }
}
