<div class="container">
<h2>interviews List</h2>
<a href="<?php echo e(route('interviews.create')); ?>" class="btn btn-primary mb-3">Create interviews</a>
<table class="table">
    <thead>
        <tr><th>name</th><th>time</th><th>question_count</th><th>answer_count</th><th>status</th><th>percentage</th><th>difficulty_level</th><th>ai_generated</th><th>duration</th><th>score</th><th>badge_id</th><th>user_id</th><th>deleted_at</th></tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $interviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->name); ?></td>
<td><?php echo e($item->time); ?></td>
<td><?php echo e($item->question_count); ?></td>
<td><?php echo e($item->answer_count); ?></td>
<td><?php echo e($item->status); ?></td>
<td><?php echo e($item->percentage); ?></td>
<td><?php echo e($item->difficulty_level); ?></td>
<td><?php echo e($item->ai_generated); ?></td>
<td><?php echo e($item->duration); ?></td>
<td><?php echo e($item->score); ?></td>
<td><?php echo e($item->badge_id); ?></td>
<td><?php echo e($item->user_id); ?></td>
<td><?php echo e($item->deleted_at); ?></td>
<td>
                        <a href="<?php echo e(route('interviews.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('interviews.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH /var/www/html/Laravel/Interview/resources/views/interviews/index.blade.php ENDPATH**/ ?>