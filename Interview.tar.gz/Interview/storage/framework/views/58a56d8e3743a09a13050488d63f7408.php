<div class="container">
<h2>batches List</h2>
<a href="<?php echo e(route('batches.create')); ?>" class="btn btn-primary mb-3">Create batches</a>
<table class="table">
    <thead>
        <tr><th>name</th><th>image</th><th>category</th><th>status</th><th>deleted_at</th></tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->name); ?></td>
<td><?php echo e($item->image); ?></td>
<td><?php echo e($item->category); ?></td>
<td><?php echo e($item->status); ?></td>
<td><?php echo e($item->deleted_at); ?></td>
<td>
                        <a href="<?php echo e(route('batches.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('batches.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH /var/www/html/Laravel/Interview/resources/views/batches/index.blade.php ENDPATH**/ ?>