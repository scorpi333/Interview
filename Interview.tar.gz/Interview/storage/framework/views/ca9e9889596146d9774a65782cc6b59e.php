<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PHP Badge</title>
  <style>
    body {
      background: #f8f9fa;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    svg {
      width: 200px;
    }
    .badge-text {
      font-family: Arial, sans-serif;
      font-weight: bold;
      fill: white;
      font-size: 28px;
    }
  </style>
</head>
<body>

  <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <!-- Background Ribbon -->
    <rect x="236" y="0" width="40" height="512" fill="#4CAF50"/>
    <rect x="248" y="0" width="8" height="512" fill="#FFD700"/>
    
    <!-- Circle Badge -->
    <circle cx="256" cy="256" r="120" fill="#4CAF50" stroke="#FFD700" stroke-width="20"/>
    
    <!-- Decorative inner ring -->
    <circle cx="256" cy="256" r="95" fill="none" stroke="#ffffff" stroke-dasharray="5,5" stroke-width="5"/>

    <!-- PHP Text -->
    <text x="50%" y="270" class="badge-text" text-anchor="middle">PHP</text>
  </svg>

</body>
</html>
<?php /**PATH /var/www/html/Laravel/Interview/resources/views/batches/badge.blade.php ENDPATH**/ ?>