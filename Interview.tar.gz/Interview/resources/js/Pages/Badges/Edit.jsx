import { useForm } from '@inertiajs/react';
import { useState } from 'react';
import { Dialog } from '@headlessui/react';
import  BadgesForm from '@/Pages/Badges/Form';
// import { X } from 'lucide-react';

export default function CreateBadgeModal({ isOpen, setIsOpen }) {
    const { data, setData, post, processing, errors, reset } = useForm({
        name: '',
        image: '',
        category: '',
        status: 'Active',
    });

    const [preview, setPreview] = useState(null);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setData('image', file);
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        post('/admin/badges', {
            onSuccess: () => {
                reset();
                setPreview(null);
                setIsOpen(false);
            },
        });
    };

    return (
        <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="relative z-50">
            <div className="fixed inset-0 bg-black/40" aria-hidden="true" />
            <div className="fixed inset-0 flex items-center justify-center p-4">
                <Dialog.Panel className="bg-white dark:bg-gray-900 max-w-lg w-full p-6 rounded-xl shadow-lg relative">
                    <button
                        onClick={() => setIsOpen(false)}
                        className="absolute top-3 right-3 text-gray-600 hover:text-gray-900 dark:text-gray-400"
                    >
                        X
                        {/* <X size={20} /> */}
                    </button>

                    <Dialog.Title className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">
                        Add Badge
                    </Dialog.Title>

                    <BadgesForm
                        data={data}
                        setData={setData}
                        post={post}
                        processing={processing}
                        errors={errors}
                        reset={reset}
                        handleImageChange={handleImageChange}
                        preview={preview}
                        handleSubmit={handleSubmit}
                    />
                </Dialog.Panel>
            </div>
        </Dialog>
    );
}
