import { toPng } from 'html-to-image';
import { useRef } from 'react';
import ClearedInterviewBadge from '@/Components/ClearedInterviewBadge';

export default function ExportableBadge({ name, language }){
    name = 'John Doe';
    language = 'JavaScript';
  const ref = useRef();

  const handleDownload = () => {
    toPng(ref.current).then((dataUrl) => {
      const link = document.createElement('a');
      link.download = `${name}-interview-badge.png`;
      link.href = dataUrl;
      link.click();
    });
  };

  return (
    <div>
      <div ref={ref}>
        <ClearedInterviewBadge name={name} language={language} />
      </div>
      <button
        onClick={handleDownload}
        className="mt-4 px-4 py-2 bg-white text-indigo-600 font-semibold rounded shadow"
      >
        Download Badge
      </button>
    </div>
  );
};
