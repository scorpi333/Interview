import { useForm } from '@inertiajs/react';
import { useState } from 'react';
import { Dialog } from '@headlessui/react';
import { v4 as uuidv4 } from 'uuid';

// import  BadgesForm from '@/Pages/Badges/Form';
// import { X } from 'lucide-react';

export default function CreateBadgeModal({ isOpen, setIsOpen, languages }) {
    const { data, setData, post, processing, errors, reset } = useForm({
        name: '',
        image: '',
        category: '',
        status: 'Active',id: uuidv4()
    });

    const [preview, setPreview] = useState(null);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setData('image', file);
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('badges.store'), {
            preserveScroll: true,
            onSuccess: () => {
                reset();
                setPreview(null);
                setIsOpen(false);
            },
            onError: (errors) => {
                console.log('Validation errors:', errors);
            },
        });
    };
    
    return (
        <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="relative z-50">
            <div className="fixed inset-0 bg-black/40" aria-hidden="true" />
            <div className="fixed inset-0 flex items-center justify-center p-4">
                <Dialog.Panel className="bg-white dark:bg-gray-900 max-w-lg w-full p-6 rounded-xl shadow-lg relative">
                    <button
                        onClick={() => setIsOpen(false)}
                        className="absolute top-3 right-3 text-gray-600 hover:text-gray-900 dark:text-gray-400"
                    >
                        X
                        {/* <X size={20} /> */}
                    </button>

                    <Dialog.Title className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">
                        Add Badge
                    </Dialog.Title>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                            {/* <input
                                type="text"
                                className="mt-1 block w-full border rounded px-3 py-2"
                                value={data.name}
                                onChange={(e) => setData('name', e.target.value)}
                            />
                            {errors.name && <div className="text-red-500 text-sm">{errors.name}</div>} */}
                             <select
                                value={data.name}
                                onChange={(e) => setData('name', e.target.value)}
                                className="mt-1 block w-full border rounded px-3 py-2"
                            >
                                <option value="">Select Language</option>
                                    {Object.entries(languages).map(([id, name]) => (
                                        <option key={id} value={id}>{name}</option>
                                    ))}
                            </select>
                            {errors.name && <div className="text-red-500 text-sm">{errors.name}</div>}
                        </div>

                        {/* <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
                            <input
                                type="text"
                                className="mt-1 block w-full border rounded px-3 py-2"
                                value={data.category}
                                onChange={(e) => setData('category', e.target.value)}
                            />
                            {errors.category && <div className="text-red-500 text-sm">{errors.category}</div>}
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Image</label>
                            <input
                                type="file"
                                accept="image/*"
                                onChange={handleImageChange}
                                className="mt-1 block w-full"
                            />
                            {errors.image && <div className="text-red-500 text-sm">{errors.image}</div>}
                            {preview && (
                                <img
                                    src={preview}
                                    alt="Preview"
                                    className="mt-3 h-32 w-32 object-cover rounded border"
                                />
                            )}
                        </div> */}

                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                            <select
                                value={data.status}
                                onChange={(e) => setData('status', e.target.value)}
                                className="mt-1 block w-full border rounded px-3 py-2"
                            >
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                            {errors.status && <div className="text-red-500 text-sm">{errors.status}</div>}
                        </div>

                        <div className="flex justify-end">
                            <button
                                type="submit"
                                disabled={processing}
                                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                            >
                                Save
                            </button>
                        </div>
                    </form>
                </Dialog.Panel>
            </div>
        </Dialog>
    );
}
