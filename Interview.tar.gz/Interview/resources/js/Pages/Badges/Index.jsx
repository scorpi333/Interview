import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, router, useForm } from '@inertiajs/react';
import CreateBadgeModal from '@/Pages/Badges/Create'; 
import { useState } from 'react';
import { usePage } from '@inertiajs/react';
import Pagination from '@/Components/Pagination';
import { Pencil, Trash2 } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { Dialog } from '@headlessui/react';
import { X } from 'lucide-react';
import ClearedInterviewBadge from '@/Components/ClearedInterviewBadge';
import { toPng } from 'html-to-image';
import { useRef } from 'react';


export default function BadgeIndex({ badges, languages }) {
    const user = usePage().props.auth.user;

    const [isModalOpen, setIsModalOpen] = useState(false);
    
    // Edit
    const [editingBadge, setEditingBadge] = useState(null);
    const {
        data: editData,
        setData: setEditData,
        put,
        reset: resetEdit,
        processing,
        errors,
        preview,
    } = useForm({ name: '', id: uuidv4() });


    const openEditModal = (badge) => {

        
        setEditData({
            id: badge.id,
            name: badge.name,
            category: badge.category,
            status: badge.status,
            image: badge.image,
        });
        setEditingBadge(badge);
    };
    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setEditData('image', file);
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setEditData('image', reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleUpdate = (e) => {
        e.preventDefault();
        if (!editingBadge) return;
        put(route('badges.update', editingBadge.id), {
            preserveScroll: true,
            onSuccess: () => {
                resetEdit();
                setEditingBadge(null);
            },
            onError: (errors) => {
                console.log('Validation errors:', errors);
            },
        });
    };
    // Delete
    const handleDelete = (id) => {
        router.delete(route('badges.destroy', id), {
            preserveScroll: true,
        });
    };
    const [showModal, setShowModal] = useState(false);
    const [badgeToDelete, setBadgeToDelete] = useState(null);
    const openDeleteModal = (badge) => {
        setBadgeToDelete(badge);
        setShowModal(true);
    };
    const closeDeleteModal = () => {
        setBadgeToDelete(null);
        setShowModal(false);
    };

    // const totalBadgeCount = badges.data.reduce((total, item) => {
    //     return total + (item.badge_count || 0);
    // }, 0);

    const ref = useRef();
    console.log(ref);
    
    const handleDownload = ({ name, language }) => {
        const finalName = name || 'badge';
        const finalLanguage = language || 'language';
        const badgeName = `${finalName}-${finalLanguage}`;
        const badgeElement = document.getElementById(badgeName);
    
        if (badgeElement) {
            toPng(badgeElement)
                .then((dataUrl) => {
                    const link = document.createElement('a');
                    link.download = `${badgeName}.png`;
                    link.href = dataUrl;
                    link.click();
                })
                .catch((error) => {
                    console.error('Error generating image:', error);
                });
        } else {
            console.error('Badge element not found:', badgeName);
        }
    };
    

    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">Badges</h2>}
        >
            <Head title="Badges" />

            <div className="py-6 px-4 max-w-7xl mx-auto">
            {user.role == 'Admin' && (
                <div className="flex justify-between items-center mb-4">
                    <h1 className="text-2xl font-bold"></h1>
                    <button
                        className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
                        onClick={() => setIsModalOpen(true)}
                    >
                        + Add Badge
                    </button>
                </div>
            )}

                <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
                    {badges.data.map((items) => (
                         (
                            <div key={items.id} className="bg-white dark:bg-gray-800 shadow rounded p-4">
                                <div className="flex-shrink-0">
                                    <ClearedInterviewBadge name={ items.user?.name || ""} language = {items.language?.name || items.badge?.language?.name} />
                                </div>
                                <div className="flex items-center gap-4">   
                                    <div className="flex-1">
                                        <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-100">
                                            {items.name}
                                        </h4>
                                    </div>
                                        <button
                                            onClick={() => handleDownload({
                                                name: items.user?.name ||"",
                                                language: items.language?.name || items.badge?.language?.name
                                              })}
                                              
                                            className="mt-4 px-4 py-2 bg-white text-indigo-600 font-semibold rounded shadow"
                                        >                                    Download
                                        </button>
                                </div>

                                <div className="mt-4 flex justify-between items-center">
                                    <span className={`text-xs px-2 py-1 rounded-full ${items.badge?.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                        {items.badge?.status || "Active"}
                                    </span>
                                    {/* <button
                                        onClick={() => openEditModal(items)}
                                        className="text-blue-500 text-sm mr-2"
                                    >
                                        <Pencil size={16} />
                                    </button>
                                    <button
                                        onClick={() => handleDelete(items.id)}
                                        className="text-red-500 text-sm"
                                    >
                                        <Trash2 size={16} />
                                    </button> */}
                                </div>
                            </div>
                        )
                    ))}
                </div>
                {badges.data.length > 0 && (
                    <Pagination 
                        currentPage={badges.current_page}
                        nextPageUrl={badges.next_page_url}
                        prevPageUrl={badges.prev_page_url}
                    />
                )}

                {badges.data.length === 0 && (
                    <div className="flex flex-col items-center justify-center text-center py-20">
                        <img src={`${window.location.origin}/storage/images/trace.svg`} alt="No badges" className="w-40 h-40 mb-6" />
                        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">No Badges yet</h2>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                            Complete interviews or challenges to earn your first certificate!
                        </p>
                        <a 
                            href={route('dashboard')} 
                            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition text-sm"
                        >
                            Start Interview
                        </a>
                    </div>
                )}
                <CreateBadgeModal isOpen={isModalOpen} setIsOpen={setIsModalOpen} languages={languages} />
            </div>

            {/* Edit Badge Modal */}
            {editingBadge && (
                <div className="fixed inset-0 flex items-center justify-center z-50">
                    <div className="bg-white dark:bg-gray-800 rounded shadow-lg p-6">
                        <h2 className="text-lg font-semibold mb-4">Edit Badge</h2>
                        <form onSubmit={handleUpdate}>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                            {/* create a select field from thre language arrray */}
                            <select
                                value={editData.name}
                                onChange={(e) => setEditData('name', e.target.value)}
                                className="mt-1 block w-full border rounded px-3 py-2"
                            >
                                <option value="">Select Language</option>
                                {languages.map((item) => (
                                    <option key={item.id} value={item.name}>
                                        {item.name}
                                    </option>
                                ))}
                            </select>
                            {errors.name && <div className="text-red-500 text-sm">{errors.name}</div>}
                            
                            {/* <input
                                type="text"
                                className="mt-1 block w-full border rounded px-3 py-2"
                                value={editData.name}
                                onChange={(e) => setData('name', e.target.value)}
                            /> */}
                            {errors.name && <div className="text-red-500 text-sm">{errors.name}</div>}
                        </div>

                        {/* <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
                            <input
                                type="text"
                                className="mt-1 block w-full border rounded px-3 py-2"
                                value={editData.category}
                                onChange={(e) => setData('category', e.target.value)}
                            />
                            {errors.category && <div className="text-red-500 text-sm">{errors.category}</div>}
                        </div> */}

                        {/* <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Image</label>
                            <input
                                type="file"
                                accept="image/*"
                                onChange={handleImageChange}
                                className="mt-1 block w-full"
                            />
                            {errors.image && <div className="text-red-500 text-sm">{errors.image}</div>}
                            {preview && (
                                <img
                                    src={preview}
                                    alt="Preview"
                                    className="mt-3 h-32 w-32 object-cover rounded border"
                                />
                            )}
                        </div> */}

                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                            <select
                                value={editData.status}
                                onChange={(e) => setData('status', e.target.value)}
                                className="mt-1 block w-full border rounded px-3 py-2"
                            >
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                            {errors.status && <div className="text-red-500 text-sm">{errors.status}</div>}
                        </div>

                        <div className="flex justify-end">
                            <button
                                type="submit"
                                disabled={processing}
                                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                            >
                                Save
                            </button>
                        </div>
                        </form>
                        <button
                            onClick={() => setEditingBadge(null)}
                            className="mt-4 text-red-500 hover:underline"
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            )}
            {/* Delete Confirmation Modal */}
            {showModal && (
                <div className="fixed inset-0 flex items-center justify-center z-50">
                    <div className="bg-white dark:bg-gray-800 rounded shadow-lg p-6">
                        <h2 className="text-lg font-semibold mb-4">Delete Badge</h2>
                        <p>Are you sure you want to delete the badge "{badgeToDelete?.name}"?</p>
                        <div className="mt-4 flex justify-end gap-2">
                            <button
                                onClick={closeDeleteModal}
                                className="px-4 py-2 text-gray-600 dark:text-gray-300"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={() => handleDelete(badgeToDelete.id)}
                                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
                            >
                                Delete
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </AuthenticatedLayout>
    );
}
