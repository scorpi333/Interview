import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import {
    Users,
    CalendarClock,
    CheckCircle,
    Clock,
    BookOpen,
    Languages,
    Award
  } from 'lucide-react';
  

export default function AdminDashboard({ stats = {} }) {
    console.log("Admin Dashboard Stats:", stats);
    
    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
                    Admin Dashboard
                </h2>
            }
        >
            <Head title="Admin Dashboard" />

            <div className="py-12">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8 space-y-6">

                    {/* Welcome Message */}
                    <div className="overflow-hidden bg-white shadow-sm sm:rounded-lg dark:bg-gray-800">
                        <div className="p-6 text-gray-900 dark:text-gray-100">
                            Welcome, Admin! 👋 Manage everything from this dashboard.
                        </div>
                    </div>

                    {/* Statistics */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        <DashboardCard title="Total Users" value={stats.total_users} icon={<Users />} />
                        <DashboardCard title="Scheduled Interviews" value={stats.scheduled_interviews} icon={<CalendarClock />} />
                        <DashboardCard title="Completed Interviews" value={stats.completed_interviews} icon={<CheckCircle />} />
                        <DashboardCard title="Pending Feedback" value={stats.pending_feedback} icon={<Clock />} />
                        <DashboardCard title="Total Certifications" value={stats.total_certifications} icon={<BookOpen />} />
                        <DashboardCard title="Total Languages" value={stats.total_languages} icon={<Languages />} />
                        <DashboardCard title="Total Badges" value={stats.total_badges} icon={<Award />} />
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                        <Link
                            href={route('users.index')}
                            className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded shadow text-center"
                        >
                            Manage Users
                        </Link>
                        <Link
                            href={route('interviews.index')}
                            className="inline-block bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded shadow text-center"
                        >
                            Manage Interviews
                        </Link>
                        {/* <Link
                            href="/admin/interviews/create"
                            className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded shadow text-center"
                        >
                            + Schedule Interview
                        </Link> */}
                        
                    </div>

                </div>
            </div>
        </AuthenticatedLayout>
    );
}

function DashboardCard({ title, value, icon }) {
    return (
        <div className="bg-white shadow p-4 rounded-2xl flex items-center space-x-4">
        <div className="text-blue-500">{icon}</div>
        <div>
          <div className="text-sm text-gray-500">{title}</div>
          <div className="text-xl font-bold">{value}</div>
        </div>
      </div>
    
    );
}
