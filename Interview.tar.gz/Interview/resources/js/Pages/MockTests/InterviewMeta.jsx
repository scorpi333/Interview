import { useState } from 'react';

const InterviewMeta = ({ interview, questions, remainingTime, formatTime, currentQuestion }) => {
    const [showHintModal, setShowHintModal] = useState(false);
    
    const currentHint = questions[currentQuestion]?.hints || "No hint available.";

    return (
        <>
            <div className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-4 flex-wrap">
                <span>Duration: {interview.duration} mins</span>
                <span className="bg-black text-white px-3 py-1 rounded font-mono text-xs">
                    ⏳ {formatTime(remainingTime)}
                </span>
                <span>Difficulty: {interview.difficulty_level}</span>
                <span>Questions: {questions.length}</span>

                {interview.type === 'mock' && (
                    <button
                        onClick={() => setShowHintModal(true)}
                        className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 transition text-xs"
                    >
                        💡 Show Hint
                    </button>
                )}
            </div>

            {showHintModal && (
                <div className="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center z-50">
                    <div className="bg-white dark:bg-gray-800 p-4 rounded shadow-lg w-80">
                        <div className="text-sm text-gray-900 dark:text-gray-100">
                            <strong>Hint:</strong>
                            <p className="mt-2">{currentHint}</p>
                        </div>
                        <button
                            onClick={() => setShowHintModal(false)}
                            className="mt-4 bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 text-xs"
                        >
                            Close
                        </button>
                    </div>
                </div>
            )}
        </>
    );
};

export default InterviewMeta;
