import { useEffect, useState } from 'react';
import { router, usePage } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';
import CodeEditor from '@/Components/CodeEditor';
import McqQuestion from '@/Components/McqQuestion';
import InterviewMeta from '@/Pages/MockTests/InterviewMeta'


export default function StartTest({ language, questions = [], interview }) {
    questions = questions.data;
    
    // language = {
    //     id: 1,
    //     name: 'JavaScript',
    // };
    

    localStorage.getItem('interview_start_time_1');
    const [currentQuestion, setCurrentQuestion] = useState(() => {
        const savedIndex = localStorage.getItem(`interview_question_index_${interview.id}`);
        return savedIndex ? parseInt(savedIndex, 10) : 0;
    });
    const [answers, setAnswers] = useState({});
    const [loading, setLoading] = useState(false);

    const [remainingTime, setRemainingTime] = useState(interview.duration * 60); // in seconds

    const timerKey = `interview_start_time_${interview.id}`;


    useEffect(() => {
        const storedStartTime = localStorage.getItem(timerKey);
        const now = Date.now();

        let startTime;
        if (storedStartTime) {
            startTime = parseInt(storedStartTime, 10);
        } else {
            startTime = now;
            localStorage.setItem(timerKey, now.toString());
        }

        const endTime = startTime + interview.duration * 60 * 1000;
        const updateRemaining = () => {
            const secondsLeft = Math.floor((endTime - Date.now()) / 1000);
            setRemainingTime(secondsLeft > 0 ? secondsLeft : 0);
        };

        updateRemaining();
        const interval = setInterval(updateRemaining, 1000);

        return () => clearInterval(interval);
    }, []);


     useEffect(() => {
        if (remainingTime === 0) {
            handleSubmit();
        }
        const savedAnswers = localStorage.getItem(`interview_answers_${interview.id}`);
        if (savedAnswers) {
            setAnswers(JSON.parse(savedAnswers));
        }
    }, [remainingTime]);

    const formatTime = (seconds) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    const handleAnswerChange = (questionId, value) => {
        const updated = { ...answers, [questionId]: value };
        setAnswers(updated);
        localStorage.setItem(`interview_answers_${interview.id}`, JSON.stringify(updated));
    };
    

    // const handleNext = () => {
    //     setCurrentQuestion((prev) => Math.min(prev + 1, questions.length - 1));
    // };

    const handleSubmit = () => {
        if (loading) return;
        setLoading(true);
        localStorage.removeItem(timerKey); // clear timer key after submission

        const fullInterviewData = {
            ...interview,
            language,
            history: questions.map((q) => ({
              user_id: interview.user_id,
              interview_question_id: q.id,
              question: q.question,
              answer: answers[q.id] || '',
              right: q.answer === answers[q.id],
              time_taken: ((interview.duration * 60) - remainingTime) / 60,
              feedback: q.feedback || '',
              ai_feedback: q.ai_feedback || '',
              interview_id: interview.id,
            })),
          };
          
        localStorage.removeItem(`interview_question_index_${interview.id}`);
        router.post(route('interview.submit'), fullInterviewData);
    };
    const handleQuestionChange = (newIndex) => {
        setCurrentQuestion(newIndex);
        localStorage.setItem(`interview_question_index_${interview.id}`, newIndex.toString());
    };
    
    
    if (remainingTime === null) return <p>Loading...</p>;


    return (
        <AuthenticatedLayout>
            <Head title="Interview" />

            <div className="max-w-4xl mx-auto py-10 space-y-6">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100">
                    🧪 {interview.name}
                </h2>
                <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded mb-6">
                    <h3 className="font-semibold text-lg mb-2">📋 Interview Rules</h3>
                    <ul className="list-disc ml-6 text-sm space-y-1">
                        <li>Do not refresh the page — your timer is running!</li>
                        <li>Each question must be answered within the given time.</li>
                        <li>Answers are auto-submitted when the timer ends.</li>
                        <li>You cannot go back to previous questions.</li>
                        <li>Cheating or external help may invalidate your test.</li>
                    </ul>
                </div>

                {/* <div className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-4">
                    Duration: {interview.duration} mins
                    <span className="bg-black text-white px-3 py-1 rounded font-mono text-xs">
                        ⏳ {formatTime(remainingTime)}
                    </span>
                    | Difficulty: {interview.difficulty_level} | Questions: {questions.length}
                    {interview.type === 'mock' && (
                        <>
                            | <span className="text-blue-600 hover:underline cursor-pointer">
                                💡 Hint Available
                            </span>
                        </>
                    )}
                </div> */}
                <InterviewMeta
                    interview={interview}
                    questions={questions}
                    currentQuestion={currentQuestion}
                    remainingTime={remainingTime}
                    formatTime={formatTime}
                />


                {questions.length > 0 ? (
                    <div className="space-y-4">
                        <div className="p-4 bg-white dark:bg-gray-800 rounded shadow">
                            
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                                <p className="font-semibold text-gray-800 dark:text-gray-100 mb-2 sm:mb-0">
                                    Q{currentQuestion + 1}: {questions[currentQuestion].question}
                                </p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">
                                    Type: {questions[currentQuestion].question_type}
                                </p>
                            </div>
                            {/* Render different input types based on question_type */}
                            {questions[currentQuestion].question_type === 'text' && (
                                <input
                                    type="text"
                                    className="w-full p-2 border rounded dark:bg-gray-700 dark:text-white"
                                    value={answers[questions[currentQuestion].id] || ''}
                                    onChange={(e) => handleAnswerChange(questions[currentQuestion].id, e.target.value)}
                                />
                            )}
                          
                            <McqQuestion
                                question={questions[currentQuestion]}
                                answer={answers[questions[currentQuestion].id]}
                                onAnswerChange={handleAnswerChange}
                            />

                            {questions[currentQuestion].question_type === 'textarea' && (
                                <textarea
                                    className="w-full p-2 border rounded dark:bg-gray-700 dark:text-white"
                                    rows="4"
                                    value={answers[questions[currentQuestion].id] || ''}
                                    onChange={(e) => handleAnswerChange(questions[currentQuestion].id, e.target.value)}
                                />
                            )}
                            {questions[currentQuestion].question_type === 'code' && (
                                <CodeEditor
                                    value={answers[questions[currentQuestion].id] || ''}
                                    onChange={(value) => handleAnswerChange(questions[currentQuestion].id, value)}
                                    language={questions.language || 'javascript'}
                                    height="200px"
                                    class-name="border rounded"
                                />
                            )}

                        </div>

                        <div className="flex justify-between">
                            <button
                                disabled={currentQuestion === 0}
                                // onClick={() => setCurrentQuestion(prev => prev - 1)}
                                onClick={() => handleQuestionChange(currentQuestion - 1)}
                                className="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded"
                            >
                                Back
                            </button>
                            
                            {/* <button onClick={() => handleQuestionChange(currentQuestion - 1)}>Previous</button> */}

                            {currentQuestion < questions.length - 1 ? (
                                <button
                                    // onClick={handleNext}
                                    onClick={() => handleQuestionChange(currentQuestion + 1)}
                                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
                                >
                                    Next
                                </button>
                                // <button onClick={() => handleQuestionChange(currentQuestion + 1)}>Next</button>

                            ) : (
                                <button
                                    onClick={handleSubmit}
                                    disabled={loading}
                                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
                                >
                                    {loading ? 'Submitting...' : 'Submit Interview'}
                                </button>
                            )}
                        </div>
                    </div>
                ) : (
                    <p>No questions available for this language.</p>
                )}
            </div>
        </AuthenticatedLayout>
    );
}
