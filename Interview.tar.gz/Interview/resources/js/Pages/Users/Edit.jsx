import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, Link } from '@inertiajs/react';
import { useEffect, useState } from 'react';

export default function EditUser({ user }) {
    const { data, setData, put, processing, errors } = useForm({
        id: user.id,
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
        address: user.address || '',
        linkedin1_url: user.linkedin1_url || '',
        skills: user.skills || '',
        experience_level: user.experience_level || '',
        role: user.role || '',
        status: user.status || '',
        resume: null,
        profile_picture: null,
    });

    const [pdfUrl, setPdfUrl] = useState(null);
    const [previewImage, setPreviewImage] = useState(null);

    if (user.resume && !pdfUrl) {
        setPdfUrl(`${window.location.origin}/storage/${user.resume}`);
    }
    
    useEffect(() => {
        if (user.resume_url) {
            setPdfUrl(user.resume_url);
        }
        if (user.profile_picture_url) {
            setPreviewImage(user.profile_picture_url);
        }
    }, [user]);

    const handleSubmit = (e) => {
        e.preventDefault();
        put(route('users.update', user.id), {
            forceFormData: true,
        });
    };

    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold text-gray-800 dark:text-white">Edit User</h2>}
        >
            <Head title="Edit User" />

            <div className="py-12 px-4 max-w-5xl mx-auto">
                <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-8 bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
                    {/* Left Side: Form Fields */}
                    <div className="space-y-5">
                        <Input label="Name" value={data.name} onChange={val => setData('name', val)} error={errors.name} />
                        <Input label="Email" value={data.email} onChange={val => setData('email', val)} error={errors.email} />
                        <Input label="Phone" value={data.phone} onChange={val => setData('phone', val)} />
                        <Input label="Address" value={data.address} onChange={val => setData('address', val)} />
                        <Input label="LinkedIn URL" value={data.linkedin1_url} onChange={val => setData('linkedin1_url', val)} />
                        <Input label="Skills" value={data.skills} onChange={val => setData('skills', val)} />
                        <Input label="Experience Level" value={data.experience_level} onChange={val => setData('experience_level', val)} />

                        {/* Role & Status */}
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">Role</label>
                                <select
                                    value={data.role}
                                    onChange={(e) => setData('role', e.target.value)}
                                    className="mt-1 block w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-white"
                                >
                                    <option>Admin</option>
                                    <option>Candidate</option>
                                    {/* <option>Interviewer</option> */}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">Status</label>
                                <select
                                    value={data.status}
                                    onChange={(e) => setData('status', e.target.value)}
                                    className="mt-1 block w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-white"
                                >
                                    <option>Active</option>
                                    <option>Inactive</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    {/* Right Side: Uploads */}
                    <div className="space-y-6">
                        {/* Profile Picture Upload */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">Profile Picture</label>
                            <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => {
                                    const file = e.target.files[0];
                                    setData("profile_picture", file);
                                    if (file) setPreviewImage(URL.createObjectURL(file));
                                }}
                                className="mt-2 block w-full text-sm"
                            />
                            {/* File Name Display */}
                            {(data.profile_picture || user.profile_picture) && (
                                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                                        <strong>Selected:</strong> {data.profile_picture ? data.profile_picture.name : user.profile_picture}
                                    </p>
                                )}
                                {/* Preview Image */}
                                {(data.profile_picture || user.profile_picture) && (
                                    <div className="mt-4">
                                        <img
                                            src={data.profile_picture ? URL.createObjectURL(data.profile_picture) : `${window.location.origin}/storage/${user.profile_picture}`}
                                            alt="Profile Preview"
                                            className="w-28 h-28 rounded-full object-cover border dark:border-gray-500 mx-auto"
                                        />
                                    </div>
                                )}
                        </div>

                        {/* Resume Upload */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">Resume (PDF/DOCX)</label>
                            <input
                                type="file"
                                accept=".pdf,.docx"
                                onChange={(e) => {
                                    const file = e.target.files[0];
                                    setData("resume", file);
                                    if (file && file.type === "application/pdf") {
                                        setPdfUrl(URL.createObjectURL(file));
                                    }
                                }}
                                className="mt-2 block w-full text-sm"
                            />
                            {data.resume && (
                                <p className="text-sm mt-2 dark:text-gray-300"><strong>Selected:</strong> {data.resume.name}</p>
                            )}
                        </div>

                        {/* Resume Preview */}
                        {pdfUrl && (
                            <div className="mt-4">
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">Resume Preview</label>
                                <div className="border rounded-md overflow-hidden h-[400px]">
                                    <iframe
                                        src={pdfUrl}
                                        className="w-full h-full"
                                        title="Resume Preview"
                                    />
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Form Actions */}
                    <div className="lg:col-span-2 flex justify-between mt-4">
                        <button
                            type="submit"
                            disabled={processing}
                            className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700"
                        >
                            Update
                        </button>
                        <Link href={route('users.index')} className="text-sm text-blue-600 hover:underline">
                            Cancel
                        </Link>
                    </div>
                </form>
            </div>
        </AuthenticatedLayout>
    );
}

// Helper input component
function Input({ label, value, onChange, type = "text", error }) {
    return (
        <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">{label}</label>
            <input
                type={type}
                value={value}
                onChange={(e) => onChange(e.target.value)}
                className="mt-1 block w-full border px-3 py-2 rounded bg-white dark:bg-gray-700 dark:text-white"
            />
            {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
        </div>
    );
}
