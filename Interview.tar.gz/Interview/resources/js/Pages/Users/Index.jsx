import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import { useState } from 'react';
import { Pencil, Trash2, Plus } from 'lucide-react';
import Pagination from '@/Components/Pagination';


export default function Index({ users }) {
    console.log(users);
    
    const { delete: destroy } = useForm();

    const handleDelete = (id) => {
        if (confirm('Are you sure you want to delete this user?')) {
            destroy(route('users.destroy', id));
        }
    };

    return (
        <AuthenticatedLayout
            header={
                <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                        User 
                    </h2>
                    {/* <Link
                        href={route('users.create')}
                        className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition"
                    >
                        <Plus className="mr-2" size={16} /> User                       
                    </Link> */}
                </div>
            }
        >

            <Head title="Users" />
            <div className="py-6 px-4 sm:px-6 lg:px-8">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white dark:bg-gray-800 shadow rounded overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-300">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-200">
                                <tr>
                                    <th className="px-4 py-3">Name</th>
                                    <th className="px-4 py-3">Email</th>
                                    <th className="px-4 py-3">Phone</th>
                                    <th className="px-4 py-3">Role</th>
                                    <th className="px-4 py-3">Status</th>
                                    <th className="px-4 py-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {users.data.map(user => (
                                    <tr key={user.id} className="border-b dark:border-gray-700">
                                        <td className="px-4 py-3">{user.name}</td>
                                        <td className="px-4 py-3">{user.email}</td>
                                        <td className="px-4 py-3">{user.phone || '-'}</td>
                                        <td className="px-4 py-3">{user.role}</td>
                                        <td className="px-4 py-3">{user.status}</td>
                                        <td className="px-4 py-3 space-x-2">
                                            <Link   
                                                href={route('users.edit', user.id)}
                                                className="text-blue-600 hover:underline"
                                            >
                                                <Pencil className="inline-block mr-1" size={16} />
                                            </Link>
                                            <button
                                                onClick={() => handleDelete(user.id)}
                                                className="text-red-600 hover:underline"
                                            >
                                                <Trash2 className="inline-block mr-1" size={16} />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                {users.length === 0 && (
                                    <tr>
                                        <td colSpan="6" className="text-center px-4 py-3">
                                            No users found.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
                <Pagination 
                    currentPage={users.current_page}
                    nextPageUrl={users.next_page_url}
                    prevPageUrl={users.prev_page_url} />
            </div>
        </AuthenticatedLayout>
    );
}
