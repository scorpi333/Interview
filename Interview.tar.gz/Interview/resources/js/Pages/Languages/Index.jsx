import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, router, useForm } from '@inertiajs/react';
import { Pencil, Trash2 } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import Modal from '@/Pages/Languages/Edit';
import { useEffect, useState } from 'react';
import { usePage } from '@inertiajs/react';
import Pagination from '@/Components/Pagination';
import ConfirmModal from '@/Components/ConfirmModal';


export default function LanguagesIndex({ languages }) {    
    // Create
    const { data, setData, post, reset, processing, errors } = useForm({ name: '', id: uuidv4() });

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('languages.store'), {
            preserveScroll: true,
            onSuccess: () => reset(),
            onError: (errors) => {
                console.log('Validation errors:', errors);
            },
        });
    };

    // Edit
    const [editingLang, setEditingLang] = useState(null);
    const [showModal, setShowModal] = useState(false);
    
    const {
        data: editData,
        setData: setEditData,
        put,
        reset: resetEdit,
    } = useForm({ name: '', id: '' });

    const openEditModal = (lang) => {
        setEditData({
            id: lang.id,
            name: lang.name,
        });
        setEditingLang(lang);
    };

    const handleUpdate = (e) => {
        e.preventDefault();
        if (!editingLang) return;
        put(route('languages.update', editingLang.id), {
            preserveScroll: true,
            onSuccess: () => {
                resetEdit();
                setEditingLang(null);
            },
            onError: (errors) => {
                console.log('Validation errors:', errors);
            },
        });
    };

    // Delete
    const handleDelete = (id) => {
        setShowModal(false);
        router.delete(route('languages.destroy', id), {
            preserveScroll: true,
            onSuccess: () => {
                setEditingLang(null);
            },
            onError: (errors) => {
                console.log('Error deleting language:', errors);
            },
        });
    };

    // flash
    const { props } = usePage();
    const flash = props.flash || {}; // fallback to avoid undefined


    const [showMessage, setShowMessage] = useState(true);
    useEffect(() => {
        if (flash.success) {
            setShowMessage(true);
            const timer = setTimeout(() => setShowMessage(false), 3000);
            return () => clearTimeout(timer);
        }
    }, [flash.success]);
    
    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
                Languages
                </h2>
            }
        >
            <Head title="Languages" />

            <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
                {/* Add New Language */}
                <form onSubmit={handleSubmit} className="mb-10 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                        <div className="flex-1">   
                            <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-gray-100">Add New Language</h3>
                            <input
                                type="text"
                                value={data.name}
                                onChange={(e) => setData('name', e.target.value)}
                                placeholder="Language name"
                                className="w-full sm:w-1/2 p-2 border rounded dark:bg-gray-900 dark:text-white"
                            />
                            {errors.name && <div className="text-red-500 text-sm">{errors.name}</div>}
                        </div>
                        <button
                            type="submit"
                            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
                        >
                            Add
                        </button>
                    </div>
                </form>

                {/* Language Cards */}
                <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                    {languages.data.map((lang) => (
                        <div
                            key={lang.id}
                            className="bg-white dark:bg-gray-800 shadow rounded-lg p-6 hover:shadow-lg transition-all"
                        >
                            <div className="mb-4">
                                <h4 className="text-xl font-semibold text-gray-900 dark:text-white">
                                    {lang.name}
                                </h4>
                                <p className="text-sm text-gray-500 dark:text-gray-400">
                                    {lang.interview_questions_count || 0} Questions
                                </p>
                            </div>
                            <div className="mt-4 flex justify-between items-center">
                                <Link
                                    href={route('interview_questions.index', { languageId: lang.id })}
                                    className="inline-block mt-2 text-sm font-medium text-blue-600 hover:underline"
                                >
                                    Manage Questions →
                                </Link>
                                <button
                                    onClick={() => openEditModal(lang)}
                                    className="text-blue-500 text-sm mr-2"
                                >
                                    <Pencil size={16} />
                                </button>
                                <button
                                    onClick={() => handleDelete(lang.id)}
                                    className="text-red-500 text-sm"
                                >
                                    <Trash2 size={16} />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
                     <Pagination 
                        currentPage={languages.current_page}
                        nextPageUrl={languages.next_page_url}
                        prevPageUrl={languages.prev_page_url} />
            </div>

            {/* Edit Modal */}
            <Modal show={!!editingLang} onClose={() => setEditingLang(null)}>
                <form onSubmit={handleUpdate} className="p-6">
                    <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        Edit Language
                    </h2>

                    <input
                        type="text"
                        value={editData.name}
                        onChange={(e) => setEditData('name', e.target.value)}
                        className="w-full p-2 border rounded dark:bg-gray-900 dark:text-white mb-4"
                    />

                    <div className="flex justify-end gap-2">
                        <button
                            type="button"
                            onClick={() => setEditingLang(null)}
                            className="px-4 py-2 text-gray-600 dark:text-gray-300"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
                        >
                            Update
                        </button>
                    </div>
                </form>
            </Modal>
            <ConfirmModal
                show={showModal}
                onClose={() => setShowModal(false)}
                onConfirm={handleDelete}
                message="Are you sure you want to delete this language?"
            />
        </AuthenticatedLayout>
    );
}
