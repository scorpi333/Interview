import React from 'react';
import { Head } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';

export default function InterviewHistoryShow({ interviewHistory }) {
  return (
    <>
       <AuthenticatedLayout
          header={
            <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
              My Interview Dashboard
            </h2>
          }
        >
      <Head title="Interview History" />

      <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 text-white">
        <h1 className="text-3xl font-bold mb-6">Interview History</h1>

        {interviewHistory.length === 0 ? (
          <p className="text-gray-400">No interview history available.</p>
        ) : (
          <div className="space-y-6">
            {interviewHistory.map((history, index) => (
              <div
                key={history.id}
                className="bg-gray-900 border border-gray-800 rounded-xl shadow p-6"
              >
                <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
                  <div>
                    <h2 className="text-xl font-semibold text-white">
                      Question {index + 1}
                    </h2>
                    <p className="text-gray-400 text-sm mt-1">
                      From Interview:{' '}
                      <span className="font-medium text-white">
                        {history.interview?.name}
                      </span>
                    </p>
                  </div>
                  <div className="mt-2 md:mt-0">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        history.right
                          ? 'bg-green-700 text-white'
                          : 'bg-red-700 text-white'
                      }`}
                    >
                      {history.right ? 'Correct' : 'Incorrect'}
                    </span>
                  </div>
                </div>

                <div className="mb-3">
                  <p className="text-gray-400 mb-1">Question:</p>
                  <p className="text-white">{history.question}</p>
                </div>

                <div className="mb-3">
                  <p className="text-gray-400 mb-1">Your Answer:</p>
                  <pre className="bg-gray-800 p-3 rounded-md overflow-x-auto whitespace-pre-wrap text-white">
                    {history.answer}
                  </pre>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-400">
                  <p>
                    <span className="font-medium text-white">Answered At:</span>{' '}
                    {new Date(history.created_at).toLocaleString()}
                  </p>
                  <p>
                    <span className="font-medium text-white">Time Taken:</span>{' '}
                    {parseFloat(history.time_taken).toFixed(2)} min
                  </p>
                </div>

                {history.feedback && (
                  <div className="mt-4">
                    <p className="text-gray-400 mb-1">Human Feedback:</p>
                    <p className="text-white">{history.feedback}</p>
                  </div>
                )}

                {history.ai_feedback && (
                  <div className="mt-2">
                    <p className="text-gray-400 mb-1">AI Feedback:</p>
                    <p className="text-white">{history.ai_feedback}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
        </AuthenticatedLayout>
    </>
  );
}
