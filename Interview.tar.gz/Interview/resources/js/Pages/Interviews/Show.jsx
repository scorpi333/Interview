// import React from 'react';
// import { Head } from '@inertiajs/react';
// import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
// import  { useState } from "react";



// export default function InterviewHistoryShow({ interviewHistory, interview }) {
//   console.log(interviewHistory);
//   console.log(interview);
//   const [showFeedback, setShowFeedback] = useState(false);

  
//   return (
//     <>
//        <AuthenticatedLayout
//           header={
//             <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
//               My Interview Dashboard
//             </h2>
//           }
//         >
//       <Head title="Interview History" />

//       <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 text-white">
//         <h1 className="text-3xl font-bold mb-6">Interview History</h1>
//         <div className="bg-white dark:bg-gray-800 p-6 rounded shadow mb-6">
//             <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
//                 {interview.name}
//             </h2>
//             <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">
//                 <span className="font-medium">Date:</span>{' '}
//                 {new Date(interview.created_at).toLocaleDateString('en-US', {
//                     year: 'numeric',
//                     month: 'long',
//                     day: 'numeric',
//                 })}
//             </p>
//             <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">
//                 <span className="font-medium">Type:</span> {interview.type === 'actual' ? 'Actual Interview' : 'Mock Interview'} | <span className="font-medium">Difficulty:</span> {interview.difficulty_level}
//             </p>
//             <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">
//                 <span className="font-medium">Status:</span> {interview.status.charAt(0).toUpperCase() + interview.status.slice(1)} | <span className="font-medium">Score:</span> {interview.score} / {interview.question_count}
//             </p>
//             <p className="text-sm text-gray-600 dark:text-gray-300">
//                 <span className="font-medium">Duration:</span> {interview.duration} seconds | <span className="font-medium">AI Generated:</span> {interview.ai_generated ? 'Yes' : 'No'}
//             </p>
//             <p className="text-sm text-gray-600 dark:text-gray-300">
//                 <span className="font-medium">User:</span> {interview.user?.name} 
//             </p>
//             <button
//                 onClick={() => setShowFeedback(true)}
//                 className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
//             >
//                 View AI Feedback
//             </button>

//              {/* Modal */}
//              {showFeedback && (
//                 <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
//                     <div className="bg-white dark:bg-gray-800 p-6 rounded shadow-lg max-w-xl w-full relative overflow-y-auto max-h-[80vh]">
//                         <button
//                             onClick={() => setShowFeedback(false)}
//                             className="absolute top-2 right-2 text-gray-600 dark:text-gray-300 hover:text-red-500 text-xl"
//                         >
//                             ×
//                         </button>
//                         <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">AI Feedback</h3>
//                         <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-line">
//                             {interview.ai_generated}
//                         </p>
//                     </div>
//                 </div>
//             )}
//         </div>

//         {interviewHistory.length === 0 ? (
//           <p className="text-gray-400">No interview history available.</p>
//         ) : (
//           <div className="space-y-6">
//             {interviewHistory.map((history, index) => (
//               <div
//                 key={history.id}
//                 className="bg-gray-900 border border-gray-800 rounded-xl shadow p-6"
//               >
//                 <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
//                   <div>
//                     <h2 className="text-xl font-semibold text-white">
//                       Question {index + 1}
//                     </h2>
//                     <p className="text-gray-400 text-sm mt-1">
//                       From Interview:{' '}
//                       <span className="font-medium text-white">
//                         {history.interview?.name}
//                       </span>
//                     </p>
//                   </div>
//                   <div className="mt-2 md:mt-0">
//                     <span
//                       className={`px-3 py-1 rounded-full text-sm font-medium ${
//                         history.right
//                           ? 'bg-green-700 text-white'
//                           : 'bg-red-700 text-white'
//                       }`}
//                     >
//                       {history.right ? 'Correct' : 'Incorrect'}
//                     </span>
//                   </div>
//                 </div>

//                 <div className="mb-3">
//                   <p className="text-gray-400 mb-1">Question:</p>
//                   <p className="text-white">{history.question}</p>
//                 </div>

//                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-3">
//                   <div>
//                     <p className="text-gray-400 mb-1">Your Answer:</p>
//                     <pre className="bg-gray-800 p-3 rounded-md overflow-x-auto whitespace-pre-wrap text-white">
//                       {history.answer}
//                     </pre>
//                   </div>
//                   <div>
//                     <p className="text-gray-400 mb-1">Correct Answer:</p>
//                     <pre className="bg-gray-800 p-3 rounded-md overflow-x-auto whitespace-pre-wrap text-green-400">
//                       {history.interview_question?.answer || 'Not Available'}
//                     </pre>
//                   </div>
//                 </div>


//                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-300">
//                   <div>
//                     <span className="font-semibold text-white">Answered At:</span>
//                     <div>{new Date(history.created_at).toLocaleString()}</div>
//                   </div>
//                   <div>
//                     <span className="font-semibold text-white">Time Taken:</span>
//                     <div>{parseFloat(history.time_taken).toFixed(2)} min</div>
//                   </div>
//                 </div>


//                 {history.feedback && (
//                   <div className="mt-4">
//                     <p className="text-gray-400 mb-1">Human Feedback:</p>
//                     <p className="text-white">{history.feedback}</p>
//                   </div>
//                 )}

//                 {history.ai_feedback && (
//                   <div className="mt-2">
//                     <p className="text-gray-400 mb-1">AI Feedback:</p>
//                     <p className="text-white">{history.ai_feedback}</p>
//                   </div>
//                 )}
//               </div>
//             ))}
//           </div>
//         )}
//       </div>
//         </AuthenticatedLayout>
//     </>
//   );
// }
import React, { useState } from 'react';
import { Head } from '@inertiajs/react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export default function InterviewHistoryShow({ interviewHistory, interview }) {
  const [showFeedback, setShowFeedback] = useState(false);

  return (
    <>
      <AuthenticatedLayout
        header={
          <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
            My Interview Dashboard
          </h2>
        }
      >
        <Head title="Interview History" />

        <main className="max-w-6xl mx-auto p-6">
          <section className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8">
            <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-6">
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-3">
                  {interview.name}
                </h1>
                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-gray-600 dark:text-gray-300">
                  <div>
                    <dt className="font-semibold">Date</dt>
                    <dd>
                      {new Date(interview.created_at).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </dd>
                  </div>
                  <div>
                    <dt className="font-semibold">Type</dt>
                    <dd>{interview.type === 'actual' ? 'Actual Interview' : 'Mock Interview'}</dd>
                  </div>
                  <div>
                    <dt className="font-semibold">Difficulty</dt>
                    <dd>{interview.difficulty_level}</dd>
                  </div>
                  <div>
                    <dt className="font-semibold">Status</dt>
                    <dd>{interview.status.charAt(0).toUpperCase() + interview.status.slice(1)}</dd>
                  </div>
                  <div>
                    <dt className="font-semibold">Score</dt>
                    <dd>
                      {interview.score} / {interview.question_count}
                    </dd>
                  </div>
                  <div>
                    <dt className="font-semibold">Duration</dt>
                    <dd>{interview.duration} seconds</dd>
                  </div>
                  <div>
                    <dt className="font-semibold">AI Generated</dt>
                    <dd>{interview.ai_generated ? 'Yes' : 'No'}</dd>
                  </div>
                  <div>
                    <dt className="font-semibold">User</dt>
                    <dd>{interview.user?.name}</dd>
                  </div>
                </dl>
              </div>

              <div className="flex items-start md:items-center">
                {interview.ai_generated ? (
                  <button
                    onClick={() => setShowFeedback(true)}
                    className="px-6 py-3 rounded-md bg-blue-600 hover:bg-blue-700 text-white font-semibold transition"
                  >
                    View AI Feedback
                  </button>
                ) : (
                  <p className="italic text-gray-500 dark:text-gray-400">No AI feedback available</p>
                )}
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mb-6">Interview History</h2>
            {interviewHistory.length === 0 ? (
              <p className="text-gray-400">No interview history available.</p>
            ) : (
              <div className="space-y-8">
                {interviewHistory.map((history, index) => (
                  <article
                    key={history.id}
                    className="bg-gray-900 border border-gray-700 rounded-xl shadow p-6"
                  >
                    <header className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-white">Question {index + 1}</h3>
                        <p className="text-gray-400 text-sm mt-1">
                          From Interview:{' '}
                          <span className="font-medium text-white">{history.interview?.name}</span>
                        </p>
                      </div>
                      <div className="mt-2 md:mt-0">
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-medium ${
                            history.right
                              ? 'bg-green-700 text-white'
                              : 'bg-red-700 text-white'
                          }`}
                        >
                          {history.right ? 'Correct' : 'Incorrect'}
                        </span>
                      </div>
                    </header>

                    <div className="mb-3">
                      <p className="text-gray-400 mb-1">Question:</p>
                      <p className="text-white">{history.question}</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-4">
                      <div>
                        <p className="text-gray-400 mb-1">Your Answer:</p>
                        <pre className="bg-gray-800 p-3 rounded-md overflow-x-auto whitespace-pre-wrap text-white">
                          {history.answer}
                        </pre>
                      </div>
                      <div>
                        <p className="text-gray-400 mb-1">Correct Answer:</p>
                        <pre className="bg-gray-800 p-3 rounded-md overflow-x-auto whitespace-pre-wrap text-green-400">
                          {history.interview_question?.answer || 'Not Available'}
                        </pre>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm text-gray-300">
                      <div>
                        <span className="font-semibold text-white">Answered At:</span>
                        <div>{new Date(history.created_at).toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="font-semibold text-white">Time Taken:</span>
                        <div>{parseFloat(history.time_taken).toFixed(2)} min</div>
                      </div>
                    </div>

                    {history.feedback && (
                      <div className="mt-4">
                        <p className="text-gray-400 mb-1">Human Feedback:</p>
                        <p className="text-white whitespace-pre-line">{history.feedback}</p>
                      </div>
                    )}

                    {history.ai_feedback && (
                      <div className="mt-2">
                        <p className="text-gray-400 mb-1">AI Feedback:</p>
                        <p className="text-white whitespace-pre-line">{history.ai_feedback}</p>
                      </div>
                    )}
                  </article>
                ))}
              </div>
            )}
          </section>

          {/* AI Feedback Modal */}
          {showFeedback && (
            <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 px-4">
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg max-w-3xl w-full max-h-[80vh] overflow-y-auto relative">
                <button
                  onClick={() => setShowFeedback(false)}
                  className="absolute top-3 right-3 text-gray-600 dark:text-gray-300 hover:text-red-500 text-2xl font-bold leading-none"
                  aria-label="Close modal"
                >
                  &times;
                </button>
                <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">
                  AI Feedback
                </h3>
                <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-line">
                    {interview.ai_generated}
                </p>
              </div>
            </div>
          )}
        </main>
      </AuthenticatedLayout>
    </>
  );
}
