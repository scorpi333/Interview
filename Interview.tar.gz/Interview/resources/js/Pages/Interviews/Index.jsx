import React, { useEffect, useState } from "react";
import axios from "axios";
import { Head } from '@inertiajs/react';
import { Card } from "@/Components/Cards/Card";
import { CardContent } from "@/Components/Cards/CardContent";
import { Table} from "@/Components/Tables/Table";
import { TableBody } from "@/Components/Tables/TableBody";
import { TableCell } from "@/Components/Tables/TableCell";
import { TableHead } from "@/Components/Tables/TableHead";
import { TableHeader } from "@/Components/Tables/TableHeader";
import { TableRow } from "@/Components/Tables/TableRow";
// import { Badge } from "@/Pages/Badges/Badge";
import ClearedInterviewBadge from '@/Components/ClearedInterviewBadge';

import Pagination from '@/Components/Pagination';

import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';


const statusColor = {
  completed: "green",
  pending: "yellow",
  failed: "red",
};

export default function Interview({ interviews }) {


  const [searchTerm, setSearchTerm] = useState("");
  const [difficultyFilter, setDifficultyFilter] = useState("");
  const [filteredInterviews, setFilteredInterviews] = useState(interviews);
  const [selectedInterview, setSelectedInterview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  // handleSearch function
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    const filtered = interviews.filter((interview) =>
      interview.name.toLowerCase().includes(e.target.value.toLowerCase())
    );
    setFilteredInterviews(filtered);
  };
  // handleDifficultyFilter function
  const handleDifficultyFilter = (e) => {
    setDifficultyFilter(e.target.value);
    const filtered = interviews.filter(
      (interview) => interview.difficulty_level === e.target.value
    );
    setFilteredInterviews(filtered);
  };
  // handleInterviewClick function
  const handleInterviewClick = (interview) => {
    setSelectedInterview(interview);
  };
  return (
    <AuthenticatedLayout
      header={
        <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
          My Interview Dashboard
        </h2>
      }
    >
      <Head title="User Dashboard" />
      <div className="py-12">
        <div className="mx-auto max-w-7xl sm:px-6 lg:px-8 space-y-10">
          <Card>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Questions</TableHead>
                    <TableHead>Answers</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Percentage</TableHead>
                    <TableHead>Difficulty</TableHead>
                    <TableHead>AI-generated</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Badge</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {interviews.data.map((interview) => (
                    <TableRow key={interview.id}>
                      <TableCell>{interview.name}</TableCell>
                      <TableCell>{interview.question_count}</TableCell>
                      <TableCell>{interview.answer_count}</TableCell>
                      <TableCell>
                        {/* <Badge
                          variant="outline"
                          className={`bg-${statusColor[interview.status] || "gray"}-100 text-${statusColor[interview.status] || "gray"}-800 border border-${statusColor[interview.status] || "gray"}-300`}
                        >
                          {interview.status}
                        </Badge> */}
                      </TableCell>
                      <TableCell>{interview.percentage}%</TableCell>
                      <TableCell>{interview.difficulty_level}</TableCell>
                      <TableCell>{interview.ai_generated ? "Yes" : "No"}</TableCell>
                      <TableCell>{interview.duration} mins</TableCell>
                      <TableCell>{interview.score}</TableCell>
                      {/* <TableCell>{interview.badge.name }</TableCell> */}
                      <TableCell>{interview.badge ? interview.badge.name : 'No badge assigned'}</TableCell>

                      <TableCell>{new Date(interview.created_at).toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <Pagination 
                  currentPage={interviews.current_page}
                  nextPageUrl={interviews.next_page_url}
                  prevPageUrl={interviews.prev_page_url} />
            </CardContent>
          </Card>
        </div>
      </div>
    </AuthenticatedLayout>
  );
}