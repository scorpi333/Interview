import InputLabel from "@/Components/InputLabel";
import Button from "@/Components/PrimaryButton";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { useState } from 'react';
import { Head, useForm, usePage } from '@inertiajs/react';

export default function ResumeUploadPage() {
    const user = usePage().props.auth.user;

   
    
    const [file, setFile] = useState(null);
    const [resumeData, setResumeData] = useState(null);
    const [previewImage, setPreviewImage] = useState(null);

    const [pdfUrl, setPdfUrl] = useState(null);
    const { data, setData, post, errors } = useForm({
        resume: null,
        profile_picture: null,
    });

    if (user.resume && !pdfUrl) {
        setPdfUrl(`${window.location.origin}/storage/${user.resume}`);
    }
    const handleFileChange = async (e) => {
        const uploadedFile = e.target.files[0];
        setFile(uploadedFile);
        setData("resume", uploadedFile);
    };

    const handleUpdate = () => {
        post(route("wizards-Step-1-post"), {
            forceFormData: true, // Required to send file via Inertia
            preserveScroll: true,
            onSuccess: () => {
                console.log("Uploaded successfully");
            },
            onError: (errors) => {
                console.log("Errors:", errors);
            },
        });
    };

    return (
        <AuthenticatedLayout>
            <Head title="Upload Resume" />
            <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* LEFT: Upload Section */}
                    <div className="space-y-6">
                        <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white">
                            Upload Resume & Profile Picture
                        </h2>

                        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-md space-y-5">
                            {/* Resume Upload */}
                            <div>
                                <InputLabel htmlFor="resume" value="Resume (PDF or DOCX)" />
                                <input
                                    type="file"
                                    id="resume"
                                    onChange={handleFileChange}
                                    accept=".pdf,.docx"
                                    className="mt-2 block w-full text-sm file:mr-4 file:py-2 file:px-4
                                        file:rounded-full file:border-0
                                        file:text-sm file:font-semibold
                                        file:bg-blue-50 file:text-blue-700
                                        hover:file:bg-blue-100 dark:file:bg-gray-600 dark:file:text-gray-200"
                                />
                                { errors.resume && (    
                                    <div className="text-red-500 text-sm mt-2">
                                        {errors.resume}
                                    </div>
                                )}
                                {/* File Name Display */}
                                {file && (
                                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                                        <strong>Selected:</strong> {file.name}
                                    </p>
                                )}
                            </div>

                            {/* Parsed Resume Info */}
                            {resumeData && (
                                <div className="bg-green-100 dark:bg-green-700 text-green-800 dark:text-green-200 p-4 rounded-md space-y-1">
                                    <p className="font-semibold">Resume Parsed:</p>
                                    <p><strong>Name:</strong> {resumeData.name}</p>
                                    <p><strong>Email:</strong> {resumeData.email}</p>
                                    <p><strong>Phone:</strong> {resumeData.phone}</p>
                                    <p><strong>LinkedIn:</strong> {resumeData.linkedin}</p>
                                    <p><strong>Skills:</strong> {resumeData.skills}</p>
                                    <p><strong>Experience:</strong> {resumeData.experience}</p>
                                    <p><strong>Address:</strong> {resumeData.address}</p>
                                </div>
                            )}

                            {/* Profile Picture Upload */}
                            <div>
                                <InputLabel htmlFor="profile_picture" value="Profile Picture" />
                                <input
                                    type="file"
                                    id="profile_picture"
                                    accept="image/*"
                                    onChange={(e) => setData("profile_picture", e.target.files[0])}
                                    className="mt-2 block w-full text-sm file:mr-4 file:py-2 file:px-4
                                        file:rounded-full file:border-0
                                        file:text-sm file:font-semibold
                                        file:bg-purple-50 file:text-purple-700
                                        hover:file:bg-purple-100 dark:file:bg-gray-600 dark:file:text-gray-200"
                                />
                                {errors.profile_picture && (
                                    <div className="text-red-500 text-sm mt-2">
                                        {errors.profile_picture}
                                    </div>
                                )}
                                {/* File Name Display */}
                                {(data.profile_picture || user.profile_picture) && (
                                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                                        <strong>Selected:</strong> {data.profile_picture ? data.profile_picture.name : user.profile_picture}
                                    </p>
                                )}
                                {/* Preview Image */}
                                {(data.profile_picture || user.profile_picture) && (
                                    <div className="mt-4">
                                        <img
                                            src={data.profile_picture ? URL.createObjectURL(data.profile_picture) : `${window.location.origin}/storage/${user.profile_picture}`}
                                            alt="Profile Preview"
                                            className="w-28 h-28 rounded-full object-cover border dark:border-gray-500 mx-auto"
                                        />
                                    </div>
                                )}
                            </div>

                            {/* Submit Button */}
                            <Button
                                onClick={handleUpdate}
                                className="w-full bg-blue-600 dark:bg-blue-700 hover:bg-blue-700 dark:hover:bg-blue-800 text-white font-semibold py-2 rounded-md transition"
                            >
                                Next
                            </Button>
                        </div>
                    </div>

                    {/* RIGHT: PDF Preview */}
                    {pdfUrl && (
                        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-md p-4">
                            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 text-center">
                                Resume Preview
                            </h3>
                            <div className="border rounded-lg overflow-hidden dark:border-gray-600">
                                <iframe
                                    src={pdfUrl}
                                    title="Resume Preview"
                                    className="w-full h-[600px]"
                                />
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
