import { useState } from "react";
import { Select } from "@/Components/Select";
import { Textarea } from "@/Components/Textarea";
import { FileInput } from "@/Components/FileInput";
import InputLabel from "@/Components/InputLabel";
import Button from "@/Components/PrimaryButton";
import TextInput from '@/Components/TextInput';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import {
    User, Mail, Phone, MapPin, Linkedin, Lock, Code, Image as ImageIcon, TrendingUp
} from "lucide-react";
import { usePage, useForm } from '@inertiajs/react';


export default function UserInfoFormPage() {
    const user = usePage().props.auth.user;
    
    const { data: formData, setData: setFormData, post, processing, errors, reset: resetEdit } = useForm({
        id: user.id,
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
        address: user.address || '',
        linkedin1_url: user.linkedin1_url || '',
        skills: user.skills || '',
        experience_level: user.experience_level || '',
    });

    const   handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };



    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('wizards-Step-2-post'), {
            preserveScroll: true,
            forceFormData: true,
            onSuccess: () => {
                resetEdit();
            },
            onError: (errors) => {
                console.log('Validation errors:', errors);
            },
        });
        
    };

    const formFieldStyle = "flex items-center gap-2";

    return (
        <AuthenticatedLayout
            header={
                <h2 className="">
                </h2>
            }
        >
            <div className="py-12 px-4 sm:px-6 lg:px-8 space-y-6 max-w-2xl mx-auto">
                {/* <h2 className="text-2xl font-semibold text-center text-gray-900 dark:text-gray-100">Fill Your Details</h2> */}
                <div className="bg-white dark:bg-gray-800 p-6 shadow-lg rounded-xl border dark:border-gray-700">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div className={formFieldStyle}>
                                <div className="w-full">
                                    <div className="flex items-center gap-2 mb-1">
                                        <User className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                                        <InputLabel htmlFor="name" value="Full Name" />
                                    </div>
                                    <TextInput id="name" name="name" value={formData.name} onChange={handleChange} required />
                                    { errors.name && (
                                        <div className="text-red-500 text-sm mt-2">
                                            {errors.name}
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className={formFieldStyle}>
                                <div className="w-full">
                                <div className="flex items-center gap-2 mb-1">
                                    <Mail className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                                    <InputLabel htmlFor="email" value="Email" />
                                </div>
                                    <TextInput id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
                                    { errors.email && (
                                        <div className="text-red-500 text-sm mt-2">
                                            {errors.email}
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className={formFieldStyle}>
                                <div className="w-full">
                                <div className="flex items-center gap-2 mb-1">
                                <Phone className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                                    <InputLabel htmlFor="phone" value="Phone" />
                                    </div>
                                    <TextInput id="phone" name="phone" value={formData.phone} onChange={handleChange} required />
                                    { errors.phone && (
                                        <div className="text-red-500 text-sm mt-2">
                                            {errors.phone}
                                        </div>
                                    )}
                                </div>
                            </div>
                            
                            <div className={formFieldStyle}>
                                <div className="w-full">
                                <div className="flex items-center gap-2 mb-1">
                                <Linkedin className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                                    <InputLabel htmlFor="linkedin1_url" value="LinkedIn URL" />
                                    </div>
                                    <TextInput id="linkedin1_url" name="linkedin1_url" type="url" value={formData.linkedin1_url} onChange={handleChange} />
                                    { errors.linkedin1_url && (
                                        <div className="text-red-500 text-sm mt-2">
                                            {errors.linkedin1_url}
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className={formFieldStyle}>
                                <div className="w-full">
                                <div className="flex items-center gap-2 mb-1">
                                <Code className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                                    <InputLabel htmlFor="skills" value="Skills" />
                                    </div>
                                    <TextInput id="skills" name="skills" value={formData.skills} onChange={handleChange} placeholder="PHP, MySQL" />
                                    { errors.skills && (
                                        <div className="text-red-500 text-sm mt-2">
                                            {errors.skills}
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className={formFieldStyle}>
                                <div className="w-full">
                                <div className="flex items-center gap-2 mb-1">
                                <TrendingUp className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                                    <InputLabel htmlFor="experience_level" value="Experience Level" />
                                    </div>
                                    <Select id="experience_level" name="experience_level" value={formData.experience_level} onChange={handleChange}>
                                        <option value="">Experience</option>
                                        <option value="Beginner">Beginner</option>
                                        <option value="Intermediate">Intermediate</option>
                                        <option value="Expert">Expert</option>
                                    </Select>
                                    { errors.experience_level && (
                                        <div className="text-red-500 text-sm mt-2">
                                            {errors.experience_level}
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className={formFieldStyle}>
                                <div className="w-full">
                                <div className="flex items-center gap-2 mb-1">
                                <MapPin className="w-5 h-5 text-gray-500 dark:text-gray-300" />
                                    <InputLabel htmlFor="address" value="Address" />
                                    </div>
                                    <Textarea id="address" name="address" value={formData.address} onChange={handleChange} rows={3} />
                                    { errors.address && (
                                        <div className="text-red-500 text-sm mt-2">
                                            {errors.address}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        <Button type="submit" className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white dark:bg-blue-700 dark:hover:bg-blue-800"
      onClick={(e) => handleSubmit(e)}

                        >
                            Save Profile
                        </Button>
                    </form>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
