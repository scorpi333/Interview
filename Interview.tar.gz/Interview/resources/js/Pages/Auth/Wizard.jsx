import React, { useState } from "react";
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';
import InputLabel from '@/Components/InputLabel';
import TextInput from '@/Components/TextInput';

export default function UserWizardPage() {
  const [form, setForm] = useState({
    phone: "",
    address: "",
    linkedin_url: "",
    password: "",
    resume: null,
    profile: "",
    status: "active",
    type: "",
    languages: [],
    role: "Candidate",
    profile_picture: null,
    experience_level: "",
    education: [{ degree: "", institution: "", year: "" }],
    skills: [],
    bio: "",
    email: ""
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;
    if (type === 'file') {
      setForm({ ...form, [name]: files[0] });
    } else {
      setForm({ ...form, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submit using Inertia.post or axios
  };

  return (
    <AuthenticatedLayout header={<h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200">User Onboarding</h2>}>
      <Head title="User Setup Wizard" />
      <div className="py-12">
        <div className="max-w-6xl mx-auto sm:px-6 lg:px-8">
          <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-xl shadow">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <InputLabel htmlFor="email" value="Email" />
                <TextInput
                  id="email"
                  type="email"
                  name="email"
                  className="mt-1 block w-full"
                  value={form.email}
                  onChange={handleChange}
                  required
                  autoComplete="username"
                />
              </div>

              <div>
                <label>Phone</label>
                <input type="text" name="phone" value={form.phone} onChange={handleChange} className="input w-full" />
              </div>

              <div>
                <label>Address</label>
                <input type="text" name="address" value={form.address} onChange={handleChange} className="input w-full" />
              </div>

              <div>
                <label>LinkedIn URL</label>
                <input type="text" name="linkedin_url" value={form.linkedin_url} onChange={handleChange} className="input w-full" />
              </div>

              <div>
                <label>Password</label>
                <input type="password" name="password" value={form.password} onChange={handleChange} className="input w-full" />
              </div>

              <div>
                <label>Resume</label>
                <input type="file" name="resume" onChange={handleChange} className="input w-full" />
              </div>

              <div>
                <label>Profile</label>
                <input type="text" name="profile" value={form.profile} onChange={handleChange} className="input w-full" />
              </div>

              <div>
                <label>Status</label>
                <select name="status" value={form.status} onChange={handleChange} className="input w-full">
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div>
                <label>Type</label>
                <input type="text" name="type" value={form.type} onChange={handleChange} className="input w-full" />
              </div>

              <div>
                <label>Languages (comma separated)</label>
                <input type="text" name="languages" value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value.split(',') })} className="input w-full" />
              </div>

              <div>
                <label>Role</label>
                <select name="role" value={form.role} onChange={handleChange} className="input w-full">
                  <option value="Admin">Admin</option>
                  <option value="Candidate">Candidate</option>
                  <option value="Interviewer">Interviewer</option>
                </select>
              </div>

              <div>
                <label>Profile Picture</label>
                <input type="file" name="profile_picture" onChange={handleChange} className="input w-full" />
              </div>

              <div>
                <label>Experience Level</label>
                <select name="experience_level" value={form.experience_level} onChange={handleChange} className="input w-full">
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Expert">Expert</option>
                </select>
              </div>

              <div className="col-span-3">
                <label>Education</label>
                {form.education.map((edu, index) => (
                  <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <input type="text" name="degree" placeholder="Degree" value={edu.degree} onChange={(e) => {
                      const newEdu = [...form.education];
                      newEdu[index].degree = e.target.value;
                      setForm({ ...form, education: newEdu });
                    }} className="input w-full" />
                    <input type="text" name="institution" placeholder="Institution" value={edu.institution} onChange={(e) => {
                      const newEdu = [...form.education];
                      newEdu[index].institution = e.target.value;
                      setForm({ ...form, education: newEdu });
                    }} className="input w-full" />
                    <input type="text" name="year" placeholder="Year" value={edu.year} onChange={(e) => {
                      const newEdu = [...form.education];
                      newEdu[index].year = e.target.value;
                      setForm({ ...form, education: newEdu });
                    }} className="input w-full" />
                  </div>
                ))}
              </div>

              <div className="col-span-3">
                <label>Skills (comma separated)</label>
                <input type="text" name="skills" value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value.split(',') })} className="input w-full" />
              </div>

              <div className="col-span-3">
                <label>Bio</label>
                <textarea name="bio" value={form.bio} onChange={handleChange} className="input w-full"></textarea>
              </div>
            </div>

            <div>
              <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-md">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </AuthenticatedLayout>
  );
}
