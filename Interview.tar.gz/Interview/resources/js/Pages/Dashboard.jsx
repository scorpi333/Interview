import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link } from '@inertiajs/react';
import { useState } from 'react';

export default function UserDashboard({
    user,
    languages = [],
    mockTests = [],
    actualTests = [],
    stats = {}
}) {
        
    // pass language and level
    const [selectedLevel, setSelectedLevel] = useState('');
    const [selectedLanguage, setSelectedLanguage] = useState('');
    
    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
                    My Interview Dashboard
                </h2>
            }
        >
            <Head title="User Dashboard" />

            <div className="py-12">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8 space-y-10">

                    {/* MOCK INTERVIEW SECTION */}
                    <section className="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6">
                        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">
                            🧪 Mock Interviews
                        </h3>

                        {/* Stats */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                            <StatCard label="Total Mock Interviews" value={stats.mock_total || 0} icon="📊" />
                            <StatCard label="Passed" value={stats.mock_passed || 0} icon="✅" />
                            <StatCard label="Failed" value={(stats.mock_total || 0) - (stats.mock_passed || 0)} icon="❌" />
                        </div>

                        {/* Start Mock Test */}
                        <div className="flex items-center space-x-3 mb-4">
                            <select
                                value={selectedLanguage}
                                onChange={(e) => setSelectedLanguage(e.target.value)}
                                className="p-2 border rounded dark:bg-gray-700 dark:text-white"
                            >
                                <option value="">Select Language</option>
                                {languages.map((lang) => (
                                    <option key={lang.id} value={lang.id}>
                                        {lang.name}
                                    </option>
                                ))}
                            </select>
                            {/* pass level of Interview fropdown */}
                            <select
                                className="p-2 border rounded dark:bg-gray-700 dark:text-white"
                                onChange={(e) => setSelectedLevel(e.target.value)}
                                value={selectedLevel}
                            >
                                <option value="">Select Level</option>
                                <option value="easy">Easy</option>
                                <option value="medium">Medium</option>
                                <option value="hard">Hard</option>
                            </select>
                            {selectedLanguage && selectedLevel && (
                                <Link
                                    href={`/mock-test/start?language_id=${selectedLanguage}&level=${selectedLevel}`}
                                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm shadow"
                                >
                                    Start Mock Test
                                </Link>
                            )}
                        </div>

                        {/* List of mock interviews */}
                        {mockTests.length > 0 ? (
                            <ul className="space-y-2 text-sm">
                                {mockTests.map((test, index) => (
                                    <li key={index} className="p-3 bg-gray-100 dark:bg-gray-700 rounded">
                                        <strong>{test.language}</strong> – {test.status} on {test.date}
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-gray-600 dark:text-gray-400">No mock interviews taken yet.</p>
                        )}
                    </section>

                    {/* ACTUAL INTERVIEW SECTION */}
                    <section className="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6">
                        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">
                            🎯 Actual Interviews
                        </h3>

                        {/* Stats */}
                        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
                            <StatCard label="Total Interviews" value={stats.actual_total || 0} icon="🎤" />
                            <StatCard label="Passed" value={stats.actual_passed || 0} icon="🏆" />
                            <StatCard label="Failed" value={(stats.actual_total || 0) - (stats.actual_passed || 0)} icon="⚠️" />
                            <StatCard label="Certificates" value={stats.certificates || 0} icon="🎓" />
                        </div>

                        {/* List of actual interviews */}
                        {actualTests.length > 0 ? (
                            <ul className="space-y-3 text-sm">
                                {actualTests.map((test, index) => (
                                    <li key={index} className="p-4 bg-gray-100 dark:bg-gray-700 rounded">
                                        <div className="flex justify-between">
                                            <div>
                                                <strong>{test.language}</strong> – {test.status} on {test.date}
                                                <p className="text-xs text-gray-500 dark:text-gray-300">
                                                    Badge: {test.badge || 'N/A'}
                                                </p>
                                            </div>
                                            {test.certificate_url && (
                                                <Link
                                                    href={test.certificate_url}
                                                    className="text-blue-600 hover:underline"
                                                    target="_blank"
                                                >
                                                    🎓 View Certificate
                                                </Link>
                                            )}
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-gray-600 dark:text-gray-400">No actual interviews yet.</p>
                        )}
                        {/* 'certifications' => $certifications,
                        'badges' => $badges,
                        'languages' => $languages, */}
                        {/* Create design for the certifications and badges */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
                            {stats.certifications && stats.certifications.length > 0 ? (
                                stats.certifications.map((cert, index) => (
                                    <div key={index} className="p-4 bg-white dark:bg-gray-800 rounded shadow">
                                        <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-100">
                                            {cert.name}
                                        </h4>
                                        <p className="text-sm text-gray-600 dark:text-gray-300">
                                            Issued on: {cert.date}
                                        </p>
                                    </div>
                                ))
                            ) : (
                                <p className="text-gray-600 dark:text-gray-400">No certifications yet.</p>
                            )}
                            {stats.badges && stats.badges.length > 0 ? (
                                stats.badges.map((badge, index) => (
                                    <div key={index} className="p-4 bg-white dark:bg-gray-800 rounded shadow">
                                        <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-100">
                                            {badge.name}
                                        </h4>
                                        <p className="text-sm text-gray-600 dark:text-gray-300">
                                            Awarded on: {badge.date}
                                        </p>
                                    </div>
                                ))
                            ) : (
                                <p className="text-gray-600 dark:text-gray-400">No badges yet.</p>
                            )}
                        </div>
                    </section>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}

// 🧩 StatCard component (reusable)
function StatCard({ label, value, icon }) {
    return (
        <div className="p-4 bg-white dark:bg-gray-800 rounded shadow text-center">
            <div className="text-2xl font-bold text-gray-800 dark:text-white">
                {icon} {value}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                {label}
            </div>
        </div>
    );
}
