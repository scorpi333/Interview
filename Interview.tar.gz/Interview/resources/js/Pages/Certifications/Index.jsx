import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, usePage, router } from '@inertiajs/react';
import Pagination from '@/Components/Pagination';
import { Pencil, Trash2, Download } from 'lucide-react';


export default function CertificationIndex({ certifications }) {
    const user = usePage().props.auth.user;
    
    console.log(certifications);
    
    const handleDelete = (id) => {
        if (!id) return;
        
    
        if (confirm('Are you sure you want to delete this certificate?')) {
            router.delete(route('certifications.destroy', id), {
                preserveScroll: true,
                onSuccess: () => {
                    console.log(`Certificate ${id} deleted.`);
                },
                onError: (errors) => {
                    console.error('Delete failed:', errors);
                },
            });
        }
    };
    
    
    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">Certifications</h2>}
        >
            <Head title="Certifications" />

            <div className="py-6 px-4 max-w-7xl mx-auto">
                {user.role === 'Admin' && (
                    <div className="flex justify-between mb-6">
                        <h3 className="text-lg font-bold dark:text-white">Certifications</h3>
                            <Link
                                href={ route('certifications.create') }
                                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
                            >   
                                + Add Certification
                            </Link>
                    </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    {certifications.data.map((cert) => (
                        <div
                            key={cert.id}
                            className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 flex flex-col"
                        >
                            <div className="rounded-2xl shadow-md bg-white dark:bg-gray-800 p-6 mb-4 border border-gray-200 dark:border-gray-700">
                                <div className="flex items-center justify-between mb-3">
                                    <h4 className="text-xl font-bold text-gray-800 dark:text-white">{cert.certificate_name}</h4>
                                    <span className="text-xs bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300 px-2 py-1 rounded-full">
                                    {cert.user.name}
                                    </span>
                                </div>

                                <div className="text-sm text-gray-600 dark:text-gray-300 space-y-1">
                                    <p><span className="font-medium">Issued by:</span> {cert.issued_by}</p>
                                    <p><span className="font-medium">Issued At:</span> {cert.issued_at}</p>
                                    <p><span className="font-medium">Valid Until:</span> {cert.valid_until}</p>
                                </div>
                                {cert.attachment?.endsWith('.pdf') ? (
                                    <iframe
                                        src={`${window.location.origin}/storage/${cert.attachment}`}
                                        title="Certificate PDF"
                                        className="w-full h-48 border rounded mb-3"
                                    />
                                ) : cert.attachment ? (
                                    <a
                                        href={cert.attachment}
                                        target="_blank"
                                        className="text-blue-500 hover:underline mb-3"
                                    >   
                                        View Attachment
                                    </a>
                                ) : (
                                    <p className="text-gray-400 text-sm mb-3">No attachment</p>
                                )}

                                <div className="flex justify-between mt-auto">
                                    <a
                                        href={`${window.location.origin}/storage/${cert.attachment}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        download
                                        className="text-blue-500 hover:underline text-sm"
                                    >
                                            <Download size={16} />
                                    </a>
                                    {/* <Link
                                        href={route('certifications.destroy', cert.id)}
                                        className="text-red-600 hover:underline text-sm"
                                    >
                                        <Trash2 size={16} />
                                    </Link> */}
                                    <button
                                     onClick={() => handleDelete(cert.id)}
                                    className="text-red-600 hover:underline text-sm"
                                    >
                                    <Trash2 size={16} />
                                    </button>

                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                {certifications.data.length > 0 && (
                    <>
                        <Pagination 
                            currentPage={certifications.current_page}
                            nextPageUrl={certifications.next_page_url}
                            prevPageUrl={certifications.prev_page_url}
                        />
                    </>
                )}
                {certifications.data.length === 0 && (
                    <div className="flex flex-col items-center justify-center text-center py-20">
                        <img src={`${window.location.origin}/storage/images/ISO-Certification-bro.png`} alt="No certificates" className="w-40 h-40 mb-6" />
                        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">No certificates yet</h2>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                            Complete interviews or challenges to earn your first certificate!
                        </p>
                        <a 
                            href={route('dashboard')} 
                            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition text-sm"
                        >
                            Start Interview
                        </a>
                    </div>
                )}


            </div>
        </AuthenticatedLayout>
    );
}
