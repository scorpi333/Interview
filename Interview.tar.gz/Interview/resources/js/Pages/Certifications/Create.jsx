import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm } from '@inertiajs/react';
import { v4 as uuidv4 } from 'uuid';


export default function CreateCertification({users, languages}) {
    console.log(users);
    console.log(languages);
    
    const { data, setData, post, processing, errors } = useForm({
        user_id: '',
        certificate_name: '',
        issued_by: 'Smart Interview',
        issued_at: '',
        valid_until: '',
        id: uuidv4(),
    });
    

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('certifications.store'),{
            preserveScroll: true,
            onSuccess: () => reset(),
            onError: (errors) => {
                console.log('Validation errors:', errors);
            },
        });
    };

    return (
        <AuthenticatedLayout
            header={<h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">Add Certification</h2>}
        >
            
            <Head title="Add Certification" />

            <div className="py-6 px-4 max-w-2xl mx-auto">
                <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 p-6 rounded shadow space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">User ID</label>
                        <select
                            className="mt-1 block w-full border rounded px-3 py-2"
                            value={data.user_id}
                            onChange={(e) => setData('user_id', e.target.value)}
                        >
                             <option value="">Select a user</option>
                             {Object.entries(users).map(([id, name]) => (
                                    <option key={id} value={id}>
                                        {name}
                                    </option>
                                ))}
                        </select>
                        {errors.user_id && <div className="text-red-500 text-sm">{errors.user_id}</div>}
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Certificate Name</label>
                        <select
                            className="mt-1 block w-full border rounded px-3 py-2"
                            value={data.certificate_name}
                            onChange={(e) => setData('certificate_name', e.target.value)}
                        >
                         <option value="">Select a Language</option>
                            {Object.entries(languages).map(([id, name]) => (
                                <option key={id} value={name}>
                                    {name}
                                </option>
                            ))}
                        </select>
                        {errors.certificate_name && <div className="text-red-500 text-sm">{errors.certificate_name}</div>}
                    </div>

                    {/* hide this div */}

                    <div className='hidden'>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Issued By</label>
                        <input
                            type="text"
                            className="mt-1 block w-full border rounded px-3 py-2"
                            value={data.issued_by}
                            onChange={(e) => setData('issued_by', "Smart Interview")}
                        />
                        {errors.issued_by && <div className="text-red-500 text-sm">{errors.issued_by}</div>}
                    </div>

                    <div className="flex gap-4">
                        <div className="w-1/2">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Issued At</label>
                            <input
                                type="date"
                                className="mt-1 block w-full border rounded px-3 py-2"
                                value={data.issued_at}
                                onChange={(e) => setData('issued_at', e.target.value)}
                            />
                            {errors.issued_at && <div className="text-red-500 text-sm">{errors.issued_at}</div>}
                        </div>

                        <div className="w-1/2">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Valid Until</label>
                            <input
                                type="date"
                                className="mt-1 block w-full border rounded px-3 py-2"
                                value={data.valid_until}
                                onChange={(e) => setData('valid_until', e.target.value)}
                            />
                            {errors.valid_until && <div className="text-red-500 text-sm">{errors.valid_until}</div>}
                        </div>
                    </div>

                    <button
                        type="submit"
                        disabled={processing}
                        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                    >
                        Save Certification
                    </button>
                </form>
            </div>
        </AuthenticatedLayout>
    );
}
