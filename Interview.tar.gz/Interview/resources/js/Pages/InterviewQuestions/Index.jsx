import InterviewQuestionCreate from '@/Pages/InterviewQuestions/Create';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import { PlusCircleIcon } from 'lucide-react';
import { useState } from 'react';
import axios from 'axios';

export default function QuestionsIndex({ interviewQuestions, languages, language_id }) {
    
    const { data, setData, post, reset } = useForm({
        language: languages[language_id],
        language_id: language_id,
        level: 'Easy',
        mcq: 5,
        textarea: 5,
        code: 5,
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        post('/admin/questions', {
            onSuccess: () => reset(),
        });
    };

    const levels = ['Easy', 'Medium', 'Hard'];

    const [isLoading, setIsLoading] = useState(false);

    const handleAIQuestionGenerate = async () => {
        setIsLoading(true);

        const payload = {
            language_id: data.language_id,
            level: data.level,
            mcq: data.mcq,
            textarea: data.textarea,
            code: data.code,
        };

        try {
            const response = await fetch('/api/generate-question', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });

            const result = await response.json();
            alert('Questions generated! You can now review or save them.'); // or display results in UI
            console.log(result); // TODO: Handle the result (populate form, show preview, etc.)
        } catch (error) {
            console.error('AI generation error:', error);
            alert('Failed to generate questions. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <AuthenticatedLayout
            header={
                <div className="flex justify-between items-center">
                    <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
                        Interview Questions
                    </h2>
                    <Link
                        href={route('interview_questions.create')}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
                    >
                        <PlusCircleIcon className="mr-2" />
                    </Link>
                </div>
            }
        >
            <Head title="Questions" />
            
            <div className="max-w-4xl mx-auto bg-white dark:bg-gray-900 p-6 rounded-xl shadow space-y-6">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-white">Generate AI Interview Questions</h2>

            <form onSubmit={handleSubmit} className="space-y-6">
                {/* Row 1: Language + Level */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Language</label>
                        <select
                            value={language_id}
                            onChange={(e) => setData({
                                language_id: e.target.value,
                                language: selectedOption.getAttribute('data-key'),
                            })}
                            className="w-full p-2 border rounded dark:bg-gray-800 dark:text-white"
                        >
                            <option value="">Select Language</option>
                            {Object.entries(languages).map(([id, name]) => (
                                <option data-key={name} value={id}>
                                    {name}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Level</label>
                        <select
                            value={data.level}
                            onChange={(e) => setData('level', e.target.value)}
                            className="w-full p-2 border rounded dark:bg-gray-800 dark:text-white"
                        >
                            <option value="">Select Level</option>
                            {levels.map((lvl) => (
                                <option key={lvl} value={lvl}>
                                    {lvl}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                {/* Row 2: Count of Questions */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">MCQ Count</label>
                        <input
                            type="number"
                            placeholder="e.g., 3"
                            value={data.mcq}
                            min={1}
                            max={10}
                            onChange={(e) => setData('mcq', e.target.value)}
                            className="w-full p-2 border rounded dark:bg-gray-800 dark:text-white"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Textarea Count</label>
                        <input
                            type="number"
                            placeholder="e.g., 2"
                            value={data.textarea}
                            min={1}
                            max={10}
                            onChange={(e) => setData('textarea', e.target.value)}
                            className="w-full p-2 border rounded dark:bg-gray-800 dark:text-white"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Code Count</label>
                        <input
                            type="number"
                            placeholder="e.g., 1"
                            value={data.code}
                            min={1}
                            max={10}
                            onChange={(e) => setData('code', e.target.value)}
                            className="w-full p-2 border rounded dark:bg-gray-800 dark:text-white"
                        />
                    </div>
                </div>

                {/* Row 3: Action Buttons */}
                <div className="flex gap-4">
                    <button
                        type="button"
                        onClick={handleAIQuestionGenerate}
                        disabled={isLoading}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded disabled:opacity-60"
                    >
                        {isLoading ? 'Generating...' : 'Generate with AI'}
                    </button>

                    <button
                        type="submit"
                        className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
                    >
                        Save Questions
                    </button>
                </div>
            </form>
        </div>

            <div className="max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">

                {/* Question Cards */}
                <div className="grid gap-6 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                    {interviewQuestions.data.map((q) => (
                        <div
                            key={q.id}
                            className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 space-y-3"
                        >
                            <h4 className="text-lg font-semibold text-gray-900 dark:text-white">
                                {q.question}
                            </h4>
                            <p className="text-sm text-gray-500 dark:text-gray-300"><strong>Answer:</strong> {q.answer}</p>
                            <p className="text-xs text-gray-400 dark:text-gray-500">
                                <span className="inline-block mr-2">🔖 {q.tags}</span>
                                <span>🌐 {q.source}</span>
                            </p>
                            <div className="flex items-center justify-between text-xs text-gray-500 mt-2">
                                <span>🧪 Level: {q.level}</span>
                                <span>📚 {q.language.name || ""}</span>
                            </div>
                            <div className="flex justify-between items-center pt-4">
                                <Link
                                    href={route('interview_questions.edit', q.id)}
                                    className="text-sm text-blue-600 hover:underline"
                                >
                                    Edit
                                </Link>
                                <Link
                                    href={route('interview_questions.destroy', q.id)}
                                    className="text-sm text-red-600 hover:underline"
                                >
                                    Delete
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
