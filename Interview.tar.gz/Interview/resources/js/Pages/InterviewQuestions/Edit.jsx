import { useState } from 'react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import { PlusCircleIcon } from 'lucide-react';

export default function AddQuestionModal({ languages, interviewQuestion }) {
    const [isOpen, setIsOpen] = useState(true); // Set to true for development preview
    console.log("Interview Question:", interviewQuestion);
    
    const { data, setData, post, reset } = useForm({
        question: interviewQuestion.question || '',
        answer: interviewQuestion.answer || '',
        level: interviewQuestion.level || '',
        tags: interviewQuestion.tags || '',
        source: interviewQuestion.source || '',
        hints: interviewQuestion.hints || '',
        question_type: interviewQuestion.question_type || '',
        language_id: interviewQuestion.language_id || '',
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('interview_questions.update',interviewQuestion.id), {
            onSuccess: () => {
                reset();
                setIsOpen(false);
            },
            onError: (errors) => {
                console.log('Validation errors:', errors);
            },
        });
    };

    return (
        <AuthenticatedLayout
            header={
                <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Interview Questions</h2>
                    <button
                        onClick={() => setIsOpen(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
                    >
                        <PlusCircleIcon size={18} />
                        Add
                    </button>
                </div>
            }
        >
            <Head title="Add Question" />
                <div className="py-6 px-4 max-w-2xl mx-auto">
                    <div className="bg-white dark:bg-gray-900 rounded-xl shadow-xl w-full max-w-xl p-6">
                        <form onSubmit={handleSubmit} className="space-y-4 text-sm">
                            {/* Language Select */}
                            <div>
                                <label className="block text-gray-700 dark:text-gray-300 mb-1">Language</label>
                                <select
                                    value={data.language_id}
                                    onChange={(e) => setData('language_id', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-md dark:bg-gray-800 dark:text-white"
                                >
                                    <option value="">Select Language</option>
                                    {Object.entries(languages).map(([id, name]) => (
                                        <option key={id} value={id}>{name}</option>
                                    ))}
                                </select>
                                {errors.language_id && (
                                    <div className="text-red-500 text-sm mt-1">{errors.language_id}</div>
                                )}
                            </div>

                            {/* Question */}
                            <div>
                                <label className="block text-gray-700 dark:text-gray-300 mb-1">Question</label>
                                <input
                                    type="text"
                                    value={data.question}
                                    onChange={(e) => setData('question', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-md dark:bg-gray-800 dark:text-white"
                                />
                                {errors.question && (
                                    <div className="text-red-500 text-sm mt-1">{errors.question}</div>
                                )}
                            </div>

                            {/* Answer */}
                            <div>
                                <label className="block text-gray-700 dark:text-gray-300 mb-1">Answer</label>
                                <textarea
                                    value={data.answer}
                                    onChange={(e) => setData('answer', e.target.value)}
                                    rows={4}
                                    className="w-full px-3 py-2 border rounded-md dark:bg-gray-800 dark:text-white"
                                ></textarea>
                                {errors.answer && (
                                    <div className="text-red-500 text-sm mt-1">{errors.answer}</div>
                                )}
                            </div>

                            {/* Level, Tags, Source, Hints */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {/* Create Select for Level */}
                                <select name="level" id="level" value={data.level} onChange={(e) => setData('level', e.target.value)} className="w-full px-3 py-2 border rounded-md dark:bg-gray-800 dark:text-white">
                                    <option value="">Select Level</option>
                                    <option value="Easy">Easy</option>
                                    <option value="Medium">Medium</option>
                                    <option value="Hard">Hard</option>
                                </select>
                                <input
                                    type="text"
                                    placeholder="Tags (comma-separated)"
                                    value={data.tags}
                                    onChange={(e) => setData('tags', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-md dark:bg-gray-800 dark:text-white"
                                />
                                <input
                                    type="text"
                                    placeholder="Source"
                                    value={data.source}
                                    onChange={(e) => setData('source', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-md dark:bg-gray-800 dark:text-white"
                                />
                                <input
                                    type="text"
                                    placeholder="Hints"
                                    value={data.hints}
                                    onChange={(e) => setData('hints', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-md dark:bg-gray-800 dark:text-white"
                                />
                            </div>

                            {/* Question Type */}
                            <div>
                                <select
                                    value={data.question_type}
                                    onChange={(e) => setData('question_type', e.target.value)}
                                    className="w-full px-3 py-2 border rounded-md dark:bg-gray-800 dark:text-white"
                                >
                                    <option value="">Level</option>
                                    <option value="mcq">MCQ</option>
                                    <option value="textarea">Textarea</option>
                                    <option value="code">Code</option>
                                </select>
                            </div>

                            {/* Action Buttons */}
                            <div className="flex justify-end pt-4 gap-3">
                                <button
                                    type="button"
                                    onClick={() => setIsOpen(false)}
                                    className="px-4 py-2 bg-gray-200 text-black rounded-md hover:bg-gray-300"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                                >
                                    Save
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
        </AuthenticatedLayout>
    );
}
