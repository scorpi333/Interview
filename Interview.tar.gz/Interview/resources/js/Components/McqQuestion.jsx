import React from 'react';

const McqQuestion = ({ question, answer, onAnswerChange }) => {
    let options = [];

    try {
        options = JSON.parse(question.option || '[]');
    } catch (err) {
        console.error("Invalid JSON in options:", question.options);
    }   
    
    return (
        question.question_type === 'mcq' && (
            options && options.length > 0 ? (
                <select
                    className="w-full p-2 border rounded dark:bg-gray-700 dark:text-white"
                    value={answer || ''}
                    onChange={(e) => onAnswerChange(question.id, e.target.value)}
                >
                    <option value="">Select an answer</option>
                    {options.map((option, index) => (
                        <option key={index} value={option}>
                            {option.replace(/</g, '‹').replace(/>/g, '›')}
                        </option>
                    ))}
                </select>
            ) : (
                <input
                    type="text"
                    className="w-full p-2 border rounded dark:bg-gray-700 dark:text-white"
                    value={answer || ''}
                    onChange={(e) => onAnswerChange(question.id, e.target.value)}
                    placeholder="Enter your answer"
                />
            )
        )
    );
    
};

export default McqQuestion;
