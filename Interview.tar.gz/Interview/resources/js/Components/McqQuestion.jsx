import React from 'react';

const McqQuestion = ({ question, answer, onAnswerChange }) => {
    let options = [];

    try {
        options = JSON.parse(question.option || '[]');
    } catch (err) {
        console.error("Invalid JSON in options:", question.options);
    }   
    
    return (
        question.question_type === 'mcq' && (
            <select
                className="w-full p-2 border rounded dark:bg-gray-700 dark:text-white"
                value={answer || ''}
                onChange={(e) => onAnswerChange(question.id, e.target.value)}
            >
                <option value="">Select an answer</option>
                {options.map((option, index) => (
                    <option key={index} value={option}>
                        {option.replace(/</g, '‹').replace(/>/g, '›')}
                    </option>
                ))}
            </select>
        )
    );
};

export default McqQuestion;
