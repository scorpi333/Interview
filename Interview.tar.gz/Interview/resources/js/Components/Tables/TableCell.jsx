export const TableCell = ({ children }) => (
  <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">{children}</td>
);