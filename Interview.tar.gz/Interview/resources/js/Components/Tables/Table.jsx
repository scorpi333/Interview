export const Table = ({ children }) => (
    <table className="min-w-full divide-y divide-gray-200">{children}</table>
  );