export const TableRow = ({ children }) => (
    <tr className="hover:bg-gray-100">{children}</tr>
  );