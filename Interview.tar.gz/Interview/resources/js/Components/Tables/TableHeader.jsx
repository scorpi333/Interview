export const TableHeader = ({ children }) => (
    <thead className="bg-gray-50">{children}</thead>
  );