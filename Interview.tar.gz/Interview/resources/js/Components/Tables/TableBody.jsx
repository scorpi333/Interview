export const TableBody = ({ children }) => (
    <tbody className="bg-white divide-y divide-gray-200">{children}</tbody>
  );