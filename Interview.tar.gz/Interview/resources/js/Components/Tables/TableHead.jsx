export const TableHead = ({ children }) => (
    <th className="px-4 py-2 text-left text-sm font-medium text-gray-500 uppercase tracking-wider">
      {children}
    </th>
  );