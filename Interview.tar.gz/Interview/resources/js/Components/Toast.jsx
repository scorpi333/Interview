import { useEffect, useState } from 'react';

export default function Toast({ message, type = 'success' }) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), 4000);
    return () => clearTimeout(timer);
  }, []);

  if (!visible || !message) return null;
  
  return (
    <div className={`fixed top-4 right-4 px-4 py-3 rounded-lg shadow-md text-white z-50 ${
      type === 'error' ? 'bg-red-600' : 'bg-green-600'
    }`}>
      {message}
    </div>
  );
}
