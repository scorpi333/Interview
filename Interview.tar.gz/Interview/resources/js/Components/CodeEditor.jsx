// import React, { useState } from 'react';
// import Editor from 'react-simple-code-editor';
// import { highlight, languages } from 'prismjs/components/prism-core';
// import 'prismjs/themes/prism-tomorrow.css'; // or any Prism theme you prefer
// import 'prismjs/components/prism-javascript';
// import 'prismjs/components/prism-python';
// import 'prismjs/components/prism-java';

// export default function CodeEditor({
//     language = 'javascript',
//     initialCode = '',
//     onChange = () => {},
// }) {
//     const [code, setCode] = useState(initialCode);

//     const handleChange = (newCode) => {
//         setCode(newCode);
//         onChange(newCode);
//     };

//     return (
//         <div className="bg-gray-900 text-white p-4 rounded-lg shadow">
//             <Editor
//                 value={code}
//                 onValueChange={handleChange}
//                 highlight={(code) => highlight(code, languages[language], language)}
//                 padding={16}
//                 className="font-mono text-sm outline-none"
//                 style={{
//                     backgroundColor: 'transparent',
//                     minHeight: '200px',
//                     whiteSpace: 'pre-wrap',
//                 }}
//             />
//         </div>
//     );
// }
import React, { useState } from 'react';
import Editor from 'react-simple-code-editor';
import { highlight, languages } from 'prismjs';
import 'prismjs/themes/prism-tomorrow.css';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-java';

export default function CodeEditor({
    language = 'javascript',
    initialCode = '',
    onChange = () => {},
}) {
    const [code, setCode] = useState(initialCode);

    const handleChange = (newCode) => {
        setCode(newCode);
        onChange(newCode);
    };

    const safeLanguage = languages[language] || languages.javascript;

    return (
        <div className="bg-gray-900 text-white p-4 rounded-lg shadow">
            <Editor
                value={code}
                onValueChange={handleChange}
                highlight={(code) => highlight(code, safeLanguage, language)}
                padding={16}
                className="font-mono text-sm outline-none"
                style={{
                    backgroundColor: 'transparent',
                    minHeight: '200px',
                    whiteSpace: 'pre-wrap',
                }}
            />
        </div>
    );
}
