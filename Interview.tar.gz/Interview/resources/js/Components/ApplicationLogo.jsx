export default function ApplicationLogo(props) {
    return (
        <div className="flex items-center space-x-2 text-2xl font-bold text-green-600">
        <img
            src="/logo.png"
            alt="Logo"
            className="h-9 w-9 rounded-full"
            style={{ width: '50px', height: 'auto' }}
        />
        <span>
            Smart
            <span className="text-gray-900 dark:text-white">Interview</span>
        </span>
        </div>

    );
}
