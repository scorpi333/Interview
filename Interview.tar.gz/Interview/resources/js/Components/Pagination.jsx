// import { Link } from '@inertiajs/react';

// export default function Pagination({ links }) {
//     console.log(links);
    
//     return (
//         <div className="flex justify-center mt-6">
//             {links.map((link, index) => (
//                 <Link
//                     key={index}
//                     href={link.url ?? '#'}
//                     dangerouslySetInnerHTML={{ __html: link.label }}
//                     className={`px-3 py-1 mx-1 text-sm rounded ${
//                         link.active
//                             ? 'bg-blue-600 text-white'
//                             : link.url
//                             ? 'bg-gray-200 hover:bg-gray-300'
//                             : 'text-gray-400'
//                     }`}
//                     disabled={!link.url}
//                 />
//             ))}
//         </div>
//     );
// }
import { Link } from '@inertiajs/react';

export default function SimplePagination({ currentPage, nextPageUrl, prevPageUrl }) {
    return (
        <div className="flex justify-center mt-6 gap-4">
            {prevPageUrl ? (
                <Link
                    href={prevPageUrl}
                    className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
                >
                    Previous
                </Link>
            ) : (
                <span className="px-4 py-2 text-gray-400">Previous</span>
            )}

            <span className="px-4 py-2 text-gray-600 font-medium">
                 {currentPage}
            </span>

            {nextPageUrl ? (
                <Link
                    href={nextPageUrl}
                    className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
                >
                    Next
                </Link>
            ) : (
                <span className="px-4 py-2 text-gray-400">Next</span>
            )}
        </div>
    );
}
