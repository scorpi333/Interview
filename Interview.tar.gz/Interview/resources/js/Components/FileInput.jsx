export const FileInput = ({ id, name, onChange, accept = "*", className = "" }) => (
    <div className="relative">
      <input
        type="file"
        id={id}
        name={name}
        onChange={onChange}
        accept={accept}
        className={`block w-full text-sm text-gray-500 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${className}`}
      />
    </div>
  );
  