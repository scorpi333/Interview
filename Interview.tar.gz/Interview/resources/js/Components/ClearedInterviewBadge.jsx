import React from 'react';
import { Sparkles, CheckCircle } from 'lucide-react';

const ClearedInterviewBadge = ({ id, name, language }) => {

  const message = `${language || "None"}`;


  return (
    <div className="w-64 h-64 mx-auto rounded-full bg-green-600 shadow-2xl border-4 border-white flex flex-col justify-center items-center text-center p-6 relative overflow-hidden">

    {/* Logo inside a white circle */}
    <div className="bg-white p-3 rounded-full shadow-lg mb-3">
      <img
        src="/logo.png"
        alt="Smart Interview Logo"
        className="h-14 w-14 object-contain"
      />
    </div>

    {/* Main Achievement Message */}
    <h2 className="text-lg font-bold text-white uppercase tracking-widest mb-1">
      {message}
    </h2>

    {/* User Name */}
    <p className="text-sm text-white">{name}</p>

    {/* Footer Branding */}
    <div className="absolute bottom-4 text-xs font-semibold text-green-100">
      Smart Interview
    </div>

    {/* Animated Checkmark */}
    {/* <CheckCircle className="absolute top-3 right-3 w-6 h-6 text-white animate-bounce" /> */}
    </div>
  );
};

export default ClearedInterviewBadge;
