<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Completion Certificate</title>
    <style>
        @page {
            size: A4;
            margin: 0;
        }

        body {
            width: 794px;
            height: 1123px;
            margin: 0 auto;
            font-family: 'DejaVu Sans', sans-serif;
            background-color: #fff;
            border: 10px solid #2c3e50;
            padding: 30px;
            box-sizing: border-box;
        }

        .certificate-container {
            border: 5px solid #2980b9;
            padding: 40px 20px;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            box-sizing: border-box;
        }

        h1 {
            font-size: 36px;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .sub-header {
            font-size: 18px;
            color: #34495e;
            margin-bottom: 10px;
        }

        .name {
            font-size: 28px;
            font-weight: bold;
            color: #16a085;
            margin: 10px 0;
        }

        .info {
            font-size: 18px;
            color: #555;
            margin-top: 20px;
        }

        .footer {
            margin-top: 40px;
            display: flex;
            justify-content: space-around;
        }

        .signature {
            text-align: center;
        }

        .signature-line {
            margin-top: 40px;
            border-top: 1px solid #000;
            width: 180px;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body>
    <div class="certificate-container">
        <div>
            <h1>Certificate of Achievement</h1>
            <div class="sub-header">Proudly Presented To</div>
            <div class="name">{{ $cred->certificate_name }}</div>
            <div class="info">
                For successfully completing the <strong>{{ $cred->issued_by }}</strong> program<br>
                Completion Date: <strong>{{ $cred->valid_until }}</strong>
            </div>
        </div>

        <div class="footer">
            <div class="signature">
                <div class="signature-line"></div>
                Instructor
            </div>
            <div class="signature">
                <div class="signature-line"></div>
                Authorized Signature
            </div>
        </div>
    </div>
</body>
</html>
