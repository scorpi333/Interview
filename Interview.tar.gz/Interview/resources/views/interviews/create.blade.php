<div class="container">
    <h2>Create interviews</h2>
    <form action="{{ route('interviews.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="name" class="form-label">name</label>
            <input type="text" class="form-control" name="name" value="{{old("name")}}">
            @error("name")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="time" class="form-label">time</label>
            <input type="text" class="form-control" name="time" value="{{old("time")}}">
            @error("time")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="question_count" class="form-label">question_count</label>
            <input type="text" class="form-control" name="question_count" value="{{old("question_count")}}">
            @error("question_count")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="answer_count" class="form-label">answer_count</label>
            <input type="text" class="form-control" name="answer_count" value="{{old("answer_count")}}">
            @error("answer_count")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="status" class="form-label">status</label>
            <input type="text" class="form-control" name="status" value="{{old("status")}}">
            @error("status")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="percentage" class="form-label">percentage</label>
            <input type="text" class="form-control" name="percentage" value="{{old("percentage")}}">
            @error("percentage")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="difficulty_level" class="form-label">difficulty_level</label>
            <input type="text" class="form-control" name="difficulty_level" value="{{old("difficulty_level")}}">
            @error("difficulty_level")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="ai_generated" class="form-label">ai_generated</label>
            <input type="text" class="form-control" name="ai_generated" value="{{old("ai_generated")}}">
            @error("ai_generated")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="duration" class="form-label">duration</label>
            <input type="text" class="form-control" name="duration" value="{{old("duration")}}">
            @error("duration")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="score" class="form-label">score</label>
            <input type="text" class="form-control" name="score" value="{{old("score")}}">
            @error("score")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="badge_id" class="form-label">badge_id</label>
            <input type="text" class="form-control" name="badge_id" value="{{old("badge_id")}}">
            @error("badge_id")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="user_id" class="form-label">user_id</label>
            <input type="text" class="form-control" name="user_id" value="{{old("user_id")}}">
            @error("user_id")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="deleted_at" class="form-label">deleted_at</label>
            <input type="text" class="form-control" name="deleted_at" value="{{old("deleted_at")}}">
            @error("deleted_at")
                <p>{{$message}}</p>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>