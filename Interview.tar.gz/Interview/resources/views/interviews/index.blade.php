<div class="container">
<h2>interviews List</h2>
<a href="{{ route('interviews.create') }}" class="btn btn-primary mb-3">Create interviews</a>
<table class="table">
    <thead>
        <tr><th>name</th><th>time</th><th>question_count</th><th>answer_count</th><th>status</th><th>percentage</th><th>difficulty_level</th><th>ai_generated</th><th>duration</th><th>score</th><th>badge_id</th><th>user_id</th><th>deleted_at</th></tr>
    </thead>
    <tbody>
        @foreach ($interviews as $item)
                <tr>
                    <td>{{$item->name}}</td>
<td>{{$item->time}}</td>
<td>{{$item->question_count}}</td>
<td>{{$item->answer_count}}</td>
<td>{{$item->status}}</td>
<td>{{$item->percentage}}</td>
<td>{{$item->difficulty_level}}</td>
<td>{{$item->ai_generated}}</td>
<td>{{$item->duration}}</td>
<td>{{$item->score}}</td>
<td>{{$item->badge_id}}</td>
<td>{{$item->user_id}}</td>
<td>{{$item->deleted_at}}</td>
<td>
                        <a href="{{ route('interviews.edit', $item->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('interviews.destroy', $item->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>