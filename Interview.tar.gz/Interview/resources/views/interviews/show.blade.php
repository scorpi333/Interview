<div class="container">
    <h2>interview Details</h2>
     <p><strong>name:</strong> {{ $interview ->name }}</p>
<p><strong>time:</strong> {{ $interview ->time }}</p>
<p><strong>question_count:</strong> {{ $interview ->question_count }}</p>
<p><strong>answer_count:</strong> {{ $interview ->answer_count }}</p>
<p><strong>status:</strong> {{ $interview ->status }}</p>
<p><strong>percentage:</strong> {{ $interview ->percentage }}</p>
<p><strong>difficulty_level:</strong> {{ $interview ->difficulty_level }}</p>
<p><strong>ai_generated:</strong> {{ $interview ->ai_generated }}</p>
<p><strong>duration:</strong> {{ $interview ->duration }}</p>
<p><strong>score:</strong> {{ $interview ->score }}</p>
<p><strong>badge_id:</strong> {{ $interview ->badge_id }}</p>
<p><strong>user_id:</strong> {{ $interview ->user_id }}</p>
<p><strong>deleted_at:</strong> {{ $interview ->deleted_at }}</p>

</div>