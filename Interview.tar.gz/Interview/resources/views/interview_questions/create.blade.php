<div class="container">
    <h2>Create interview_questions</h2>
    <form action="{{ route('interview_questions.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="question" class="form-label">question</label>
            <input type="text" class="form-control" name="question" value="{{old("question")}}">
            @error("question")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="answer" class="form-label">answer</label>
            <input type="text" class="form-control" name="answer" value="{{old("answer")}}">
            @error("answer")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="level" class="form-label">level</label>
            <input type="text" class="form-control" name="level" value="{{old("level")}}">
            @error("level")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="attachment" class="form-label">attachment</label>
            <input type="text" class="form-control" name="attachment" value="{{old("attachment")}}">
            @error("attachment")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="tags" class="form-label">tags</label>
            <input type="text" class="form-control" name="tags" value="{{old("tags")}}">
            @error("tags")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="source" class="form-label">source</label>
            <input type="text" class="form-control" name="source" value="{{old("source")}}">
            @error("source")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="hints" class="form-label">hints</label>
            <input type="text" class="form-control" name="hints" value="{{old("hints")}}">
            @error("hints")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="language_id" class="form-label">language_id</label>
            <input type="text" class="form-control" name="language_id" value="{{old("language_id")}}">
            @error("language_id")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="deleted_at" class="form-label">deleted_at</label>
            <input type="text" class="form-control" name="deleted_at" value="{{old("deleted_at")}}">
            @error("deleted_at")
                <p>{{$message}}</p>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>