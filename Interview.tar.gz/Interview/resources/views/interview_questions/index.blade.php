<div class="container">
<h2>interview_questions List</h2>
<a href="{{ route('interview_questions.create') }}" class="btn btn-primary mb-3">Create interview_questions</a>
<table class="table">
    <thead>
        <tr><th>question</th><th>answer</th><th>level</th><th>attachment</th><th>tags</th><th>source</th><th>hints</th><th>language_id</th><th>deleted_at</th></tr>
    </thead>
    <tbody>
        @foreach ($interview_questions as $item)
                <tr>
                    <td>{{$item->question}}</td>
<td>{{$item->answer}}</td>
<td>{{$item->level}}</td>
<td>{{$item->attachment}}</td>
<td>{{$item->tags}}</td>
<td>{{$item->source}}</td>
<td>{{$item->hints}}</td>
<td>{{$item->language_id}}</td>
<td>{{$item->deleted_at}}</td>
<td>
                        <a href="{{ route('interview_questions.edit', $item->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('interview_questions.destroy', $item->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>