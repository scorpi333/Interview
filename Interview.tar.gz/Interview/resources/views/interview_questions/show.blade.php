<div class="container">
    <h2>interviewQuestion Details</h2>
     <p><strong>question:</strong> {{ $interviewQuestion ->question }}</p>
<p><strong>answer:</strong> {{ $interviewQuestion ->answer }}</p>
<p><strong>level:</strong> {{ $interviewQuestion ->level }}</p>
<p><strong>attachment:</strong> {{ $interviewQuestion ->attachment }}</p>
<p><strong>tags:</strong> {{ $interviewQuestion ->tags }}</p>
<p><strong>source:</strong> {{ $interviewQuestion ->source }}</p>
<p><strong>hints:</strong> {{ $interviewQuestion ->hints }}</p>
<p><strong>language_id:</strong> {{ $interviewQuestion ->language_id }}</p>
<p><strong>deleted_at:</strong> {{ $interviewQuestion ->deleted_at }}</p>

</div>