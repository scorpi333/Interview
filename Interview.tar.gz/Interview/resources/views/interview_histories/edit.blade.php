<div class="container">
    <h2>Edit interviewHistory</h2>
    <form action="{{ route('interview_histories.update', $interviewHistory->id) }}" method="POST">
        @csrf
        @method("PATCH")
        <div class="mb-3">
            <label for="question" class="form-label">question</label>
            <input type="text" class="form-control" name="question" value="{{old("question", $interviewHistory["question"])}}">
            @error("question")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="answer" class="form-label">answer</label>
            <input type="text" class="form-control" name="answer" value="{{old("answer", $interviewHistory["answer"])}}">
            @error("answer")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="right" class="form-label">right</label>
            <input type="text" class="form-control" name="right" value="{{old("right", $interviewHistory["right"])}}">
            @error("right")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="time_taken" class="form-label">time_taken</label>
            <input type="text" class="form-control" name="time_taken" value="{{old("time_taken", $interviewHistory["time_taken"])}}">
            @error("time_taken")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="feedback" class="form-label">feedback</label>
            <input type="text" class="form-control" name="feedback" value="{{old("feedback", $interviewHistory["feedback"])}}">
            @error("feedback")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="ai_feedback" class="form-label">ai_feedback</label>
            <input type="text" class="form-control" name="ai_feedback" value="{{old("ai_feedback", $interviewHistory["ai_feedback"])}}">
            @error("ai_feedback")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="interview_id" class="form-label">interview_id</label>
            <input type="text" class="form-control" name="interview_id" value="{{old("interview_id", $interviewHistory["interview_id"])}}">
            @error("interview_id")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="interview_question_id" class="form-label">interview_question_id</label>
            <input type="text" class="form-control" name="interview_question_id" value="{{old("interview_question_id", $interviewHistory["interview_question_id"])}}">
            @error("interview_question_id")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="user_id" class="form-label">user_id</label>
            <input type="text" class="form-control" name="user_id" value="{{old("user_id", $interviewHistory["user_id"])}}">
            @error("user_id")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="deleted_at" class="form-label">deleted_at</label>
            <input type="text" class="form-control" name="deleted_at" value="{{old("deleted_at", $interviewHistory["deleted_at"])}}">
            @error("deleted_at")
                <p>{{$message}}</p>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>