<div class="container">
    <h2>interviewHistory Details</h2>
     <p><strong>question:</strong> {{ $interviewHistory ->question }}</p>
<p><strong>answer:</strong> {{ $interviewHistory ->answer }}</p>
<p><strong>right:</strong> {{ $interviewHistory ->right }}</p>
<p><strong>time_taken:</strong> {{ $interviewHistory ->time_taken }}</p>
<p><strong>feedback:</strong> {{ $interviewHistory ->feedback }}</p>
<p><strong>ai_feedback:</strong> {{ $interviewHistory ->ai_feedback }}</p>
<p><strong>interview_id:</strong> {{ $interviewHistory ->interview_id }}</p>
<p><strong>interview_question_id:</strong> {{ $interviewHistory ->interview_question_id }}</p>
<p><strong>user_id:</strong> {{ $interviewHistory ->user_id }}</p>
<p><strong>deleted_at:</strong> {{ $interviewHistory ->deleted_at }}</p>

</div>