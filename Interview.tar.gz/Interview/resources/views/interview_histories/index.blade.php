<div class="container">
<h2>interview_histories List</h2>
<a href="{{ route('interview_histories.create') }}" class="btn btn-primary mb-3">Create interview_histories</a>
<table class="table">
    <thead>
        <tr><th>question</th><th>answer</th><th>right</th><th>time_taken</th><th>feedback</th><th>ai_feedback</th><th>interview_id</th><th>interview_question_id</th><th>user_id</th><th>deleted_at</th></tr>
    </thead>
    <tbody>
        @foreach ($interview_histories as $item)
                <tr>
                    <td>{{$item->question}}</td>
<td>{{$item->answer}}</td>
<td>{{$item->right}}</td>
<td>{{$item->time_taken}}</td>
<td>{{$item->feedback}}</td>
<td>{{$item->ai_feedback}}</td>
<td>{{$item->interview_id}}</td>
<td>{{$item->interview_question_id}}</td>
<td>{{$item->user_id}}</td>
<td>{{$item->deleted_at}}</td>
<td>
                        <a href="{{ route('interview_histories.edit', $item->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('interview_histories.destroy', $item->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>