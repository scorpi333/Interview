<div class="container">
    <h2>Edit badge</h2>
    <form action="{{ route('badges.update', $badge->id) }}" method="POST">
        @csrf
        @method("PATCH")
        <div class="mb-3">
            <label for="name" class="form-label">name</label>
            <input type="text" class="form-control" name="name" value="{{old("name", $badge["name"])}}">
            @error("name")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="image" class="form-label">image</label>
            <input type="text" class="form-control" name="image" value="{{old("image", $badge["image"])}}">
            @error("image")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="category" class="form-label">category</label>
            <input type="text" class="form-control" name="category" value="{{old("category", $badge["category"])}}">
            @error("category")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="status" class="form-label">status</label>
            <input type="text" class="form-control" name="status" value="{{old("status", $badge["status"])}}">
            @error("status")
                <p>{{$message}}</p>
            @enderror
        </div>
<div class="mb-3">
            <label for="deleted_at" class="form-label">deleted_at</label>
            <input type="text" class="form-control" name="deleted_at" value="{{old("deleted_at", $badge["deleted_at"])}}">
            @error("deleted_at")
                <p>{{$message}}</p>
            @enderror
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>