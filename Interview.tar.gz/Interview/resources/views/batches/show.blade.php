<div class="container">
    <h2>badge Details</h2>
     <p><strong>name:</strong> {{ $badge ->name }}</p>
<p><strong>image:</strong> {{ $badge ->image }}</p>
<p><strong>category:</strong> {{ $badge ->category }}</p>
<p><strong>status:</strong> {{ $badge ->status }}</p>
<p><strong>deleted_at:</strong> {{ $badge ->deleted_at }}</p>

</div>