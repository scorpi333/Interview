<div class="container">
<h2>badges List</h2>
<a href="{{ route('badges.create') }}" class="btn btn-primary mb-3">Create badges</a>
<table class="table">
    <thead>
        <tr><th>name</th><th>image</th><th>category</th><th>status</th><th>deleted_at</th></tr>
    </thead>
    <tbody>
        @foreach ($badges as $item)
                <tr>
                    <td>{{$item->name}}</td>
<td>{{$item->image}}</td>
<td>{{$item->category}}</td>
<td>{{$item->status}}</td>
<td>{{$item->deleted_at}}</td>
<td>
                        <a href="{{ route('badges.edit', $item->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('badges.destroy', $item->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>