<div class="container">
    <h2>language Details</h2>
     <p><strong>name:</strong> {{ $language ->name }}</p>
<p><strong>deleted_at:</strong> {{ $language ->deleted_at }}</p>

</div>